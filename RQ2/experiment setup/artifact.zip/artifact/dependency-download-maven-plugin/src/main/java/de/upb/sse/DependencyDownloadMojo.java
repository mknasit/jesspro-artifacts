package de.upb.sse;

import org.apache.maven.model.Dependency;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Component;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.project.MavenProject;
import org.eclipse.aether.RepositorySystem;
import org.eclipse.aether.RepositorySystemSession;
import org.eclipse.aether.artifact.Artifact;
import org.eclipse.aether.artifact.DefaultArtifact;
import org.eclipse.aether.collection.CollectRequest;
import org.eclipse.aether.graph.DependencyFilter;
import org.eclipse.aether.repository.RemoteRepository;
import org.eclipse.aether.resolution.*;
import org.eclipse.aether.util.artifact.JavaScopes;
import org.eclipse.aether.util.filter.DependencyFilterUtils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

@Mojo( name = "dependency-download", threadSafe = true )
public class DependencyDownloadMojo extends AbstractMojo {
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_RESET = "\u001B[0m";

    @Component
    private RepositorySystem repoSystem;

    @Parameter( defaultValue = "${repositorySystemSession}", readonly = true )
    private RepositorySystemSession repoSession;

    @Parameter( defaultValue = "${project.remoteProjectRepositories}", readonly = true )
    private List<RemoteRepository> remoteRepos;

    @Parameter(property = "project", readonly = true)
    private MavenProject project;

    @Parameter( property = "ddload.transitive", defaultValue = "false" )
    private boolean downloadTransitive;

    @Parameter( property = "ddload.outdir", defaultValue = "dependency" )
    private String outputDirectory;

    @Override
    public void execute() throws MojoExecutionException, MojoFailureException {
        getLog().info("Started execution of the dependency-download-maven-plugin");

        ArtifactRequest request = new ArtifactRequest();
        request.setRepositories(remoteRepos);

        List<ArtifactResult> artifactResults = new ArrayList<>();

        List<Dependency> dependencies = project.getDependencies();

        for (Dependency dependency : dependencies) {
            if (dependency.getScope().equals("test")) continue;

            Artifact artifact;
            try {
                String gid = dependency.getGroupId();
                String aid = dependency.getArtifactId();
                String version = dependency.getVersion();
                artifact = new DefaultArtifact(String.format("%s:%s:%s", gid, aid, version));
            } catch (IllegalArgumentException e) {
                getLog().warn(ANSI_RED + String.format("Could not resolve dependency %s", dependency) + ANSI_RESET);
                continue;
            }


            try {

                getLog().info(String.format("Resolving artifact %s", artifact));
                if (!downloadTransitive) {
                    request.setArtifact(artifact);

                    ArtifactResult result = repoSystem.resolveArtifact(repoSession, request);
                    artifactResults.add(result);

                    getLog().info(ANSI_GREEN + String.format("Resolved artifact %s from %s", artifact, result.getRepository()) + ANSI_RESET);
                } else {
                    getLog().info("Resolving transitive dependencies of artifact " + artifact);
                    DependencyFilter classpathFilter = DependencyFilterUtils.classpathFilter(JavaScopes.COMPILE, JavaScopes.PROVIDED);

                    CollectRequest collectRequest = new CollectRequest();
                    collectRequest.setRoot(new org.eclipse.aether.graph.Dependency(artifact, JavaScopes.COMPILE));
                    collectRequest.setRepositories(remoteRepos);

                    DependencyRequest dependencyRequest = new DependencyRequest(collectRequest, classpathFilter);
                    List<ArtifactResult> singleArtifactResults = repoSystem.resolveDependencies(repoSession, dependencyRequest).getArtifactResults();
                    artifactResults.addAll(singleArtifactResults);
                }

            } catch (ArtifactResolutionException e) {
                getLog().warn(ANSI_RED + String.format("Could not resolve artifact %s from %s", artifact, remoteRepos) + ANSI_RESET);
            } catch (DependencyResolutionException e) {
                getLog().warn(ANSI_RED + String.format("Could not resolve dependency: %s", e.getMessage()) + ANSI_RESET);
            }

            copyArtifacts(artifactResults);

        }
    }

    private void copyArtifacts (List<ArtifactResult> artifactResults) {
        for (ArtifactResult artifactResult : artifactResults) {
            copyArtifact(artifactResult);
        }
    }

    private void copyArtifact (ArtifactResult artifactResult) {
        File artifactFile = artifactResult.getArtifact().getFile();
        Path fullOutputPath = Paths.get(outputDirectory, artifactFile.getName());
        try {
            fullOutputPath.toFile().getParentFile().mkdirs();
            Files.copy(artifactFile.toPath(), fullOutputPath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            getLog().warn(ANSI_RED + String.format("Could not copy artifact %s to %s", artifactFile.getName(), fullOutputPath) + ANSI_RESET);
        }
    }
}
