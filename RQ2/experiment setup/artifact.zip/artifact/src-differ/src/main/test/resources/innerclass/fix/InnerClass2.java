class InnerClass2 {
    class Inner {
        Inner() {
            String a = "a";
        }
    }
}