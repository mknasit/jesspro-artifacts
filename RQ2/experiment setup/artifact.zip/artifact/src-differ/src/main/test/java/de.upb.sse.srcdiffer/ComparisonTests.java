package de.upb.sse.srcdiffer;

import de.upb.sse.srcdiffer.comparison.Comparator;
import de.upb.sse.srcdiffer.model.diff.ClassDiff;
import de.upb.sse.srcdiffer.model.diff.DiffType;
import de.upb.sse.srcdiffer.model.diff.FileDiff;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ComparisonTests {
    Comparator comparator = new Comparator();

    String getStringFromFile(String filePath) throws IOException {
        return Files.readString(Path.of(filePath));
    }

    @Test
    @DisplayName("Test method difference within inner class")
    void innerClassesTest1() throws IOException {
        String vulClass = getStringFromFile("src/main/test/resources/innerclass/vul/InnerClass1.java");
        String fixClass = getStringFromFile("src/main/test/resources/innerclass/fix/InnerClass1.java");
        FileDiff diff = new FileDiff("repo", "fix", "123", "vulPath", "fixPath", vulClass, fixClass, DiffType.CHANGED);
        ClassDiff classDiff = comparator.compare(diff);
        assertEquals("InnerClass1.Inner.method()", classDiff.getChangedMethods().get(0));
    }

    @Test
    @DisplayName("Test constructor difference within inner class")
    void innerClassesTest2() throws IOException {
        String vulClass = getStringFromFile("src/main/test/resources/innerclass/vul/InnerClass2.java");
        String fixClass = getStringFromFile("src/main/test/resources/innerclass/fix/InnerClass2.java");
        FileDiff diff = new FileDiff("repo", "fix", "123", "vulPath", "fixPath", vulClass, fixClass, DiffType.CHANGED);
        ClassDiff classDiff = comparator.compare(diff);
        assertEquals("InnerClass2.Inner.Inner()", classDiff.getChangedMethods().get(0));
    }

    @Test
    @DisplayName("Test <clinit> through changing static field")
    void initTest1() throws IOException {
        String vulClass = getStringFromFile("src/main/test/resources/init/vul/Init1.java");
        String fixClass = getStringFromFile("src/main/test/resources/init/fix/Init1.java");
        FileDiff diff = new FileDiff("repo", "fix", "123", "vulPath", "fixPath", vulClass, fixClass, DiffType.CHANGED);
        ClassDiff classDiff = comparator.compare(diff);
        assertEquals(2, classDiff.getClinitChanges().size());
    }
}
