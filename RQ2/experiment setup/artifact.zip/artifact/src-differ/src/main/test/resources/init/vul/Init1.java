class Init1 {
    public static String a = "b";

    class Inner {
        static {
            int b = 4;
        }
    }
}