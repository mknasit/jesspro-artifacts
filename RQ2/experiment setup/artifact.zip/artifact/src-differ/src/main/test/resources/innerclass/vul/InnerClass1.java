class InnerClass1 {

    class Inner {

        void method() {
            String a  = "a";
        }
    }
}