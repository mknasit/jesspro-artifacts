class InnerClass2 {
    class Inner {
        Inner() {
            String a = "b";
        }
    }
}