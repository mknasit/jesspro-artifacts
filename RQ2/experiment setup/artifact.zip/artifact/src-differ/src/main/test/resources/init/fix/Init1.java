class Init1 {
    public static String a = "a";

    class Inner {
        static {
            int b = 5;
        }
    }
}