package de.upb.sse.srcdiffer.util;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.*;
import de.upb.sse.srcdiffer.model.NodeWithPartialSignature;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class SignatureUtil {

    public static List<String> getClassSignatures(List<TypeDeclaration<?>> classDecs) {
        return classDecs.stream()
                .map(SignatureUtil::getClassSignature)
                .collect(Collectors.toList());
    }

    public static String getClassSignature(TypeDeclaration<?> classDec) {
        StringBuilder builder = new StringBuilder();
        Optional<ClassOrInterfaceDeclaration> parentClassOpt = classDec.findAncestor(ClassOrInterfaceDeclaration.class);
        while (parentClassOpt.isPresent()) {
            ClassOrInterfaceDeclaration parentClass = parentClassOpt.get();
            builder.append(parentClass.getNameAsString());
            builder.append(".");
            parentClassOpt = parentClass.findAncestor(ClassOrInterfaceDeclaration.class);
        }
        builder.append(classDec.getNameAsString());
        return builder.toString();
    }

    public static List<NodeWithPartialSignature<CallableDeclaration>> getPartialMethodSignatures(List<CallableDeclaration> callableDeclarations) {
        return callableDeclarations.stream()
                .map(SignatureUtil::getPartialMethodSignature)
                .collect(Collectors.toList());
    }

    public static NodeWithPartialSignature<CallableDeclaration> getPartialMethodSignature(CallableDeclaration cd) {
        String declaringClass = getDeclaringClass(cd);
        if (declaringClass.isEmpty()) return new NodeWithPartialSignature<>(cd.getSignature().asString(), cd, cd.isStatic());
        return new NodeWithPartialSignature<>(declaringClass.substring(1) + "." + cd.getSignature().asString(), cd, cd.isStatic());
    }

    public static List<NodeWithPartialSignature<FieldDeclaration>> getPartialFieldSignatures(List<FieldDeclaration> fieldDeclarations) {
        return fieldDeclarations.stream()
                .map(SignatureUtil::getPartialFieldSignature)
                .collect(Collectors.toList());
    }

    public static NodeWithPartialSignature<FieldDeclaration> getPartialFieldSignature(FieldDeclaration fd) {
        List<VariableDeclarator> variableDeclarators = fd.getVariables();
        StringBuilder variableName = new StringBuilder();
        for (int i = 0; i < variableDeclarators.size(); i++) {
            if (i > 0) variableName.append("&");
            variableName.append(variableDeclarators.get(i));
        }
        String declaringClass = getDeclaringClass(fd);
        if (declaringClass.isEmpty()) return new NodeWithPartialSignature<>(variableName.toString(), fd, fd.isStatic());
        return new NodeWithPartialSignature<>(declaringClass.substring(1) + "." + variableName, fd, fd.isStatic());
    }

    private static String getDeclaringClass(Node n) {
        Optional<ClassOrInterfaceDeclaration> parentDecOpt = n.findAncestor(ClassOrInterfaceDeclaration.class);
        if (parentDecOpt.isEmpty()) return "";
        ClassOrInterfaceDeclaration parentDec = parentDecOpt.get();
        return getDeclaringClass(parentDec) + "." + parentDec.getNameAsString();
    }
}
