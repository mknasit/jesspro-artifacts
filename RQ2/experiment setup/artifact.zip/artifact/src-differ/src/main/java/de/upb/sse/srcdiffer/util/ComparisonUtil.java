package de.upb.sse.srcdiffer.util;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.CallableDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.EnumConstantDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.nodeTypes.NodeWithSimpleName;
import de.upb.sse.srcdiffer.model.NodeWithPartialSignature;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ComparisonUtil {

    public static <T extends Node> List<NodeWithPartialSignature<T>> getVulIntersection(List<NodeWithPartialSignature<T>> vulMethods, List<NodeWithPartialSignature<T>> fixMethods) {
        List<String> fixSignatures = fixMethods.stream().map(NodeWithPartialSignature::getPartialSignature).collect(Collectors.toList());

        return vulMethods.stream()
                .filter(md -> fixSignatures.contains(md.getPartialSignature()))
                .collect(Collectors.toList());
    }

    public static <T extends Node> List<NodeWithPartialSignature<T>> getFixIntersection(List<NodeWithPartialSignature<T>> vulMethods, List<NodeWithPartialSignature<T>> fixMethods) {
        List<String> vulSignatures = vulMethods.stream().map(NodeWithPartialSignature::getPartialSignature).collect(Collectors.toList());

        return fixMethods.stream()
                .filter(md -> vulSignatures.contains(md.getPartialSignature()))
                .collect(Collectors.toList());
    }

    public static <T extends Node> List<NodeWithPartialSignature<T>> getRemovedMethods(List<NodeWithPartialSignature<T>> vulMethods, List<NodeWithPartialSignature<T>> fixMethods) {
        List<String> fixSignatures = fixMethods.stream().map(NodeWithPartialSignature::getPartialSignature).collect(Collectors.toList());

        return vulMethods.stream()
                .filter(md -> !fixSignatures.contains(md.getPartialSignature()))
                .collect(Collectors.toList());
    }

    public static <T extends Node> List<NodeWithPartialSignature<T>> getAddedMethods(List<NodeWithPartialSignature<T>> vulMethods, List<NodeWithPartialSignature<T>> fixMethods) {
        List<String> vulSignatures = vulMethods.stream().map(NodeWithPartialSignature::getPartialSignature).collect(Collectors.toList());

        return fixMethods.stream()
                .filter(md -> !vulSignatures.contains(md.getPartialSignature()))
                .collect(Collectors.toList());
    }

    public static <T extends Node> List<String> getChangedMethodSignatures(List<NodeWithPartialSignature<T>> vulMethods, List<NodeWithPartialSignature<T>> fixMethods) {
        List<String> changedMethodSignatures = new ArrayList<>();
        for (NodeWithPartialSignature<T> vulMethod : vulMethods) {
            for (NodeWithPartialSignature<T> fixMethod : fixMethods) {
                if (!vulMethod.getPartialSignature().equals(fixMethod.getPartialSignature())) continue;
                if (equalNodes(vulMethod.getNode(), fixMethod.getNode())) continue;

                changedMethodSignatures.add(vulMethod.getPartialSignature());
            }
        }
        return changedMethodSignatures;
    }

    private <T extends Node> List<NodeWithPartialSignature<T>> filterStaticNodes(List<NodeWithPartialSignature<T>> nodes) {
        return nodes.stream().filter(NodeWithPartialSignature::isStatic).collect(Collectors.toList());
    }

    private <T extends Node> List<NodeWithPartialSignature<T>> filterNonStaticNodes(List<NodeWithPartialSignature<T>> nodes) {
        return nodes.stream().filter(n -> !n.isStatic()).collect(Collectors.toList());
    }

    public static <T extends Node> boolean equalNodes(List<T> nodes1, List<T> nodes2) {
        if (nodes1.size() != nodes2.size()) return false;

        return nodes1.stream()
                .allMatch(n1 -> nodes2.stream()
                        .anyMatch(n2 -> equalNodes(n1, n2))
                );
    }

    public static <T extends Node> boolean equalNodes(T node1, T node2) {
        Node commentlessNode1 = node1.removeComment();
        Node commentlessNode2 = node2.removeComment();
        return commentlessNode1.equals(commentlessNode2);
    }

    public static boolean methodIsInClassDeclaration(CallableDeclaration<?> methodDec, List<TypeDeclaration<?>> classDecs) {
        Optional<ClassOrInterfaceDeclaration> methodClassDecOpt = methodDec.findAncestor(ClassOrInterfaceDeclaration.class);
        if (methodClassDecOpt.isEmpty()) return false;

        ClassOrInterfaceDeclaration methodClassDec = methodClassDecOpt.get();
        return classDecs.stream()
                .map(NodeWithSimpleName::getNameAsString)
                .anyMatch(className -> className.equals(methodClassDec.getNameAsString()));
    }

    public static boolean isInObjectCreationExp(Node n) {
        Optional<Node> parentNodeOpt = n.getParentNode();
        if (parentNodeOpt.isEmpty()) return false;

        Node parentNode = parentNodeOpt.get();
        return parentNode instanceof ObjectCreationExpr;
    }

    public static boolean isInEnumConstantDec(Node n) {
        Optional<Node> parentNodeOpt = n.getParentNode();
        if (parentNodeOpt.isEmpty()) return false;

        Node parentNode = parentNodeOpt.get();
        return parentNode instanceof EnumConstantDeclaration;
    }
}
