package de.upb.sse.srcdiffer.util;

public class GitUtil {

    public static String getProjectName(String repoUrl) {
        String cleanedRepoUrl = repoUrl.replace(".git", "");
        String[] splitUrl = cleanedRepoUrl.split("/");
        if (splitUrl.length < 1) return "";
        return splitUrl[splitUrl.length - 1];
    }
}
