package de.upb.sse.srcdiffer.model;

import com.github.javaparser.ast.Node;

public class NodeWithPartialSignature<T extends Node> {
    private final String partialSignature;
    private final T node;
    private final boolean isStatic;

    public NodeWithPartialSignature(String partialSignature, T node) {
        this(partialSignature, node, false);
    }

    public NodeWithPartialSignature(String partialSignature, T node, boolean isStatic) {
        this.partialSignature = partialSignature;
        this.node = node;
        this.isStatic = isStatic;
    }

    public String getPartialSignature() {
        return partialSignature;
    }

    public T getNode() {
        return node;
    }

    public boolean isStatic() {
        return isStatic;
    }

    @Override
    public String toString() {
        return "NodeWithPartialSignature{" +
                "partialSignature='" + partialSignature + '\'' +
                ", node=" + node +
                ", isStatic=" + isStatic +
                '}';
    }
}
