package de.upb.sse.srcdiffer.model.kb;

public class Commit {
    private String id;
    private String repository;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRepository() {
        return repository;
    }

    public void setRepository(String repository) {
        this.repository = repository;
    }

    @Override
    public String toString() {
        return "Commit{" +
                "id='" + id + '\'' +
                ", repository='" + repository + '\'' +
                '}';
    }
}
