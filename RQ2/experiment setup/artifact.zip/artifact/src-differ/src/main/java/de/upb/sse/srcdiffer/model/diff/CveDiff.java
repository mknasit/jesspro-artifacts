package de.upb.sse.srcdiffer.model.diff;

import java.util.ArrayList;
import java.util.List;

public class CveDiff {
    private final String id;
    private final List<FixDiff> fixDiffs = new ArrayList<>();

    public CveDiff(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public List<FixDiff> getFixDiffs() {
        return fixDiffs;
    }

    public FixDiff getFixDiff(String fixId) {
        return fixDiffs.stream()
                .filter(diff -> diff.getId().equals(fixId))
                .findAny()
                .orElse(null);
    }

    public void addFixDiff(FixDiff fixDiff) {
        this.fixDiffs.add(fixDiff);
    }

    @Override
    public String toString() {
        return "CveDiff{" +
                "id='" + id + '\'' +
                ", fixDiffs=" + fixDiffs +
                '}';
    }
}
