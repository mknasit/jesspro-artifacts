package de.upb.sse.srcdiffer.model.diff;

public enum DiffType {
    CHANGED, REMOVED, ADDED;
}
