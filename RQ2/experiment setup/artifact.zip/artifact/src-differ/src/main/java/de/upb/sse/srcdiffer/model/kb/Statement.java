package de.upb.sse.srcdiffer.model.kb;

import java.util.List;

public class Statement {
    private String vulnerability_id;
//    private List<Note> notes;
    private List<Fix> fixes;

    public String getVulnerability_id() {
        return vulnerability_id;
    }

    public void setVulnerability_id(String vulnerability_id) {
        this.vulnerability_id = vulnerability_id;
    }

//    public List<Note> getNotes() {
//        return notes;
//    }
//
//    public void setNotes(List<Note> notes) {
//        this.notes = notes;
//    }

    public List<Fix> getFixes() {
        return fixes;
    }

    public void setFixes(List<Fix> fixes) {
        this.fixes = fixes;
    }

    public boolean hasFixes() {
        return fixes != null && fixes.size() > 0;
    }

    public boolean hasCommits() {
        if (!hasFixes()) return false;

        return fixes.stream().allMatch(Fix::hasCommits);
    }

    @Override
    public String toString() {
        return "Statement{" + '\n' +
                "  vulnerability_id='" + vulnerability_id + '\'' + '\n' + ',' +
//                "  notes=" + notes + '\n' +
                ", fixes=" + fixes + '\n' +
                '}';
    }
}
