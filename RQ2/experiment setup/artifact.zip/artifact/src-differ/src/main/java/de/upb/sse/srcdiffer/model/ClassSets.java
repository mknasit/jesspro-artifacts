package de.upb.sse.srcdiffer.model;

import com.github.javaparser.ast.body.TypeDeclaration;

import java.util.List;

public class ClassSets {
    private final List<TypeDeclaration<?>> onlyVulClasses;
    private final List<TypeDeclaration<?>> onlyFixClasses;
    private final List<MatchingNodes<TypeDeclaration<?>>> intersectingClasses;

    public ClassSets(List<TypeDeclaration<?>> onlyVulClasses,
                     List<TypeDeclaration<?>> onlyFixClasses,
                     List<MatchingNodes<TypeDeclaration<?>>> intersectingClasses) {
        this.onlyVulClasses = onlyVulClasses;
        this.onlyFixClasses = onlyFixClasses;
        this.intersectingClasses = intersectingClasses;
    }

    public List<TypeDeclaration<?>> getOnlyVulClasses() {
        return onlyVulClasses;
    }

    public List<TypeDeclaration<?>> getOnlyFixClasses() {
        return onlyFixClasses;
    }

    public List<MatchingNodes<TypeDeclaration<?>>> getIntersectingClasses() {
        return intersectingClasses;
    }

    @Override
    public String toString() {
        return "ClassSets{" +
                "onlyVulClasses=" + onlyVulClasses +
                ", onlyFixClasses=" + onlyFixClasses +
                ", intersectingClasses=" + intersectingClasses +
                '}';
    }
}
