package de.upb.sse.srcdiffer.comparison;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.nodeTypes.modifiers.NodeWithStaticModifier;
import de.upb.sse.srcdiffer.model.ClassSets;
import de.upb.sse.srcdiffer.model.MatchingNodes;
import de.upb.sse.srcdiffer.model.NodeWithPartialSignature;
import de.upb.sse.srcdiffer.model.diff.ClassDiff;
import de.upb.sse.srcdiffer.model.diff.FileDiff;
import de.upb.sse.srcdiffer.util.ComparisonUtil;
import de.upb.sse.srcdiffer.util.SignatureUtil;

import java.util.*;
import java.util.stream.Collectors;

@SuppressWarnings("rawtypes")
public class Comparator {
    private final JavaParser javaParser = new JavaParser();

    public ClassDiff compare(FileDiff diff) {
        ClassDiff classDiff = new ClassDiff(getClassName(diff.getFixFilePath()), diff.getVulFilePath(), diff.getFixFilePath(), diff.getDiffType());

        CompilationUnit vulCu = parseStringToCompilationUnit(diff.getVulClass());
        CompilationUnit fixCu = parseStringToCompilationUnit(diff.getFixClass());

        ClassSets classSets = getClassSets(vulCu, fixCu);
        List<TypeDeclaration<?>> onlyVulClasses = classSets.getOnlyVulClasses();
        List<TypeDeclaration<?>> onlyFixClasses = classSets.getOnlyFixClasses();
        List<MatchingNodes<TypeDeclaration<?>>> intersectingClasses = classSets.getIntersectingClasses();

        List<CallableDeclaration> vulMethods = getMethods(vulCu).stream()
                .filter(m -> !ComparisonUtil.methodIsInClassDeclaration(m, onlyVulClasses))
                .filter(m -> !ComparisonUtil.methodIsInClassDeclaration(m, onlyFixClasses))
                .collect(Collectors.toList());

        List<CallableDeclaration> fixMethods = getMethods(fixCu).stream()
                .filter(m -> !ComparisonUtil.methodIsInClassDeclaration(m, onlyVulClasses))
                .filter(m -> !ComparisonUtil.methodIsInClassDeclaration(m, onlyFixClasses))
                .collect(Collectors.toList());

        List<NodeWithPartialSignature<CallableDeclaration>> vulMethodSignatures = SignatureUtil.getPartialMethodSignatures(vulMethods);
        List<NodeWithPartialSignature<CallableDeclaration>> fixMethodSignatures = SignatureUtil.getPartialMethodSignatures(fixMethods);

        List<NodeWithPartialSignature<CallableDeclaration>> removedMethods = ComparisonUtil.getRemovedMethods(vulMethodSignatures, fixMethodSignatures);
        List<NodeWithPartialSignature<CallableDeclaration>> addedMethods = ComparisonUtil.getAddedMethods(vulMethodSignatures, fixMethodSignatures);
        List<NodeWithPartialSignature<CallableDeclaration>> commonVulMethods = ComparisonUtil.getVulIntersection(vulMethodSignatures, fixMethodSignatures);
        List<NodeWithPartialSignature<CallableDeclaration>> commonFixMethods = ComparisonUtil.getFixIntersection(vulMethodSignatures, fixMethodSignatures);


        classDiff.addAddedMethods(addedMethods.stream().map(NodeWithPartialSignature::getPartialSignature).collect(Collectors.toList()));
        classDiff.addRemovedMethods(removedMethods.stream().map(NodeWithPartialSignature::getPartialSignature).collect(Collectors.toList()));

        List<String> changedMethodSignatures = ComparisonUtil.getChangedMethodSignatures(commonVulMethods, commonFixMethods);
        classDiff.addChangedMethods(changedMethodSignatures);

        classDiff.addRemovedInnerClasses(SignatureUtil.getClassSignatures(onlyVulClasses));
        classDiff.addAddedInnerClasses(SignatureUtil.getClassSignatures(onlyFixClasses));

        List<MatchingNodes<TypeDeclaration<?>>> initChanges = getUnequalInit(intersectingClasses);
        List<MatchingNodes<TypeDeclaration<?>>> clinitChanges = getUnequalClinit(intersectingClasses);
        classDiff.addInitChanges(SignatureUtil.getClassSignatures(initChanges.stream()
                .map(MatchingNodes::getFixNode)
                .collect(Collectors.toList()))
        );

        classDiff.addClinitChanges(SignatureUtil.getClassSignatures(clinitChanges.stream()
                .map(MatchingNodes::getFixNode)
                .collect(Collectors.toList()))
        );

        for (MatchingNodes<TypeDeclaration<?>> classDec : initChanges) {
            ConstructorDeclaration shortestConstructor = getShortestConstructor(classDec.getVulNode(), classDec.getFixNode());
            if (shortestConstructor == null) continue;

            String shortestConstructorSignature = SignatureUtil.getPartialMethodSignature(shortestConstructor).getPartialSignature();
            classDiff.addChangedMethod(shortestConstructorSignature);
        }

        return classDiff;
    }

    private List<MatchingNodes<TypeDeclaration<?>>> getUnequalClinit(List<MatchingNodes<TypeDeclaration<?>>> matchingClasses) {
        List<MatchingNodes<TypeDeclaration<?>>> unequalClinit = new ArrayList<>();
        for (MatchingNodes<TypeDeclaration<?>> matchingNodes : matchingClasses) {
            if (equalClinit(matchingNodes.getVulNode(), matchingNodes.getFixNode())) continue;
            unequalClinit.add(matchingNodes);
        }
        return unequalClinit;
    }

    private List<MatchingNodes<TypeDeclaration<?>>> getUnequalInit(List<MatchingNodes<TypeDeclaration<?>>> matchingClasses) {
        List<MatchingNodes<TypeDeclaration<?>>> unequalInit = new ArrayList<>();
        for (MatchingNodes<TypeDeclaration<?>> matchingNodes : matchingClasses) {
            if (equalInit(matchingNodes.getVulNode(), matchingNodes.getFixNode())) continue;
            unequalInit.add(matchingNodes);
        }
        return unequalInit;
    }

    private boolean equalClinit(TypeDeclaration<?> vulClass, TypeDeclaration<?> fixClass) {
        List<FieldDeclaration> vulFieldDec = getFields(vulClass);
        List<FieldDeclaration> fixFieldDec = getFields(fixClass);

        List<FieldDeclaration> staticVulFieldDec = vulFieldDec.stream()
                .filter(NodeWithStaticModifier::isStatic)
                .collect(Collectors.toList());

        List<FieldDeclaration> staticFixFieldDec = fixFieldDec.stream()
                .filter(NodeWithStaticModifier::isStatic)
                .collect(Collectors.toList());

        if (!ComparisonUtil.equalNodes(staticVulFieldDec, staticFixFieldDec)) return false;

        List<InitializerDeclaration> vulInitDec = getInitializers(vulClass);
        List<InitializerDeclaration> fixInitDec = getInitializers(fixClass);

        List<InitializerDeclaration> staticVulInitDec = vulInitDec.stream()
                .filter(InitializerDeclaration::isStatic)
                .collect(Collectors.toList());

        List<InitializerDeclaration> staticFixInitDec = fixInitDec.stream()
                .filter(InitializerDeclaration::isStatic)
                .collect(Collectors.toList());

        return ComparisonUtil.equalNodes(staticVulInitDec, staticFixInitDec);
    }

    private boolean equalInit(TypeDeclaration<?> vulClass, TypeDeclaration<?> fixClass) {
        List<FieldDeclaration> vulFieldDec = getFields(vulClass);
        List<FieldDeclaration> fixFieldDec = getFields(fixClass);

        List<FieldDeclaration> nonStaticVulFieldDec = vulFieldDec.stream()
                .filter(fd -> !fd.isStatic())
                .collect(Collectors.toList());

        List<FieldDeclaration> nonStaticFixFieldDec = fixFieldDec.stream()
                .filter(fd -> !fd.isStatic())
                .collect(Collectors.toList());

        if (!ComparisonUtil.equalNodes(nonStaticVulFieldDec, nonStaticFixFieldDec)) return false;

        List<InitializerDeclaration> vulInitDec = getInitializers(vulClass);
        List<InitializerDeclaration> fixInitDec = getInitializers(fixClass);

        List<InitializerDeclaration> staticVulInitDec = vulInitDec.stream()
                .filter(id -> !id.isStatic())
                .collect(Collectors.toList());

        List<InitializerDeclaration> staticFixInitDec = fixInitDec.stream()
                .filter(id -> !id.isStatic())
                .collect(Collectors.toList());

        return ComparisonUtil.equalNodes(staticVulInitDec, staticFixInitDec);
    }

    private CompilationUnit parseStringToCompilationUnit(String clazz) {
        ParseResult<CompilationUnit> parseResult = javaParser.parse(clazz);
        Optional<CompilationUnit> cuOpt = parseResult.getResult();
        return cuOpt.orElse(null);
    }

    private List<CallableDeclaration> getMethods(Node n) {
        List<CallableDeclaration> allMethods = n.findAll(CallableDeclaration.class);
        return allMethods.stream()
                .filter(m -> !ComparisonUtil.isInObjectCreationExp(m))
                .filter(m -> !ComparisonUtil.isInEnumConstantDec(m))
                .collect(Collectors.toList());
    }

    private List<FieldDeclaration> getFields(Node n) {
        List<FieldDeclaration> allFields = n.findAll(FieldDeclaration.class);
        return allFields.stream()
                .filter(f -> !ComparisonUtil.isInObjectCreationExp(f))
                .filter(f -> !ComparisonUtil.isInEnumConstantDec(f))
                .collect(Collectors.toList());
    }

    private List<InitializerDeclaration> getInitializers(Node n) {
        List<InitializerDeclaration> allInitializers = n.findAll(InitializerDeclaration.class);
        return allInitializers.stream()
                .filter(i -> !ComparisonUtil.isInObjectCreationExp(i))
                .filter(i -> !ComparisonUtil.isInEnumConstantDec(i))
                .collect(Collectors.toList());
    }

    private String getClassName(String classPath) {
        String[] splitClassPath = classPath.split("/");
        if (splitClassPath.length < 1) return "";
        String fileName = splitClassPath[splitClassPath.length - 1];
        return fileName.replace(".java", "");
    }

    private ConstructorDeclaration getShortestConstructor(TypeDeclaration<?> vulClass, TypeDeclaration<?> fixClass) {
        List<ConstructorDeclaration> vulConstructors = vulClass.findAll(ConstructorDeclaration.class);
        List<ConstructorDeclaration> fixConstructors = fixClass.findAll(ConstructorDeclaration.class);

        List<ConstructorDeclaration> matchingConstructors = vulConstructors.stream()
                .filter(vcd -> fixConstructors.stream()
                        .map(fcd -> fcd.getSignature().asString())
                        .collect(Collectors.toList())
                        .contains(vcd.getSignature().asString())
                )
                .collect(Collectors.toList());

        if (matchingConstructors.size() < 1) return null;

        matchingConstructors.sort(java.util.Comparator.comparingInt(cd -> cd.getParameters().size()));

        return matchingConstructors.get(0);
    }

    private List<TypeDeclaration> getAllClassDeclarations(CompilationUnit cu) {
        return cu.findAll(TypeDeclaration.class);
    }

    private ClassSets getClassSets(CompilationUnit vulCu, CompilationUnit fixCu) {
        List<TypeDeclaration> vulClasses = getAllClassDeclarations(vulCu);
        List<TypeDeclaration> fixClasses = getAllClassDeclarations(fixCu);

        List<TypeDeclaration<?>> onlyVul = vulClasses.stream()
                .filter(vc -> fixClasses.stream()
                        .noneMatch(fc -> fc.getNameAsString().equals(vc.getNameAsString())))
                .map(item -> (TypeDeclaration<?>) item)
                .collect(Collectors.toList());

        List<TypeDeclaration<?>> onlyFix = fixClasses.stream()
                .filter(fc -> vulClasses.stream()
                        .noneMatch(vc -> vc.getNameAsString().equals(fc.getNameAsString()))
                )
                .map(item -> (TypeDeclaration<?>) item)
                .collect(Collectors.toList());

        List<MatchingNodes<TypeDeclaration<?>>> intersection = new ArrayList<>();
        for (TypeDeclaration vulClass : vulClasses) {
            for (TypeDeclaration fixClass : fixClasses) {
                if (!vulClass.getNameAsString().equals(fixClass.getNameAsString())) continue;

                intersection.add(new MatchingNodes<>((TypeDeclaration<?>) vulClass, (TypeDeclaration<?>) fixClass));
            }
        }

        return new ClassSets(onlyVul, onlyFix, intersection);
    }

}
