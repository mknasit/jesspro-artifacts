package de.upb.sse.srcdiffer.model.kb;

import java.util.List;

public class Fix {
    private String id;
    private List<Commit> commits;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<Commit> getCommits() {
        return commits;
    }

    public void setCommits(List<Commit> commits) {
        this.commits = commits;
    }

    public boolean hasCommits() {
        return commits != null && commits.size() > 0;
    }

    @Override
    public String toString() {
        return "Fix{" +
                "id='" + id + '\'' +
                ", commits=" + commits +
                '}';
    }
}
