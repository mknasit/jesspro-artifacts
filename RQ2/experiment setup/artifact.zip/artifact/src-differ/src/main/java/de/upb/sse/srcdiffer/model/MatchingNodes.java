package de.upb.sse.srcdiffer.model;

import com.github.javaparser.ast.Node;

public class MatchingNodes<T extends Node> {
    private final T vulNode;
    private final T fixNode;

    public MatchingNodes(T vulNode, T fixNode) {
        this.vulNode = vulNode;
        this.fixNode = fixNode;
    }

    public T getVulNode() {
        return vulNode;
    }

    public T getFixNode() {
        return fixNode;
    }

    @Override
    public String toString() {
        return "MatchingNodes{" +
                "vulNode=" + vulNode +
                ", fixNode=" + fixNode +
                '}';
    }
}
