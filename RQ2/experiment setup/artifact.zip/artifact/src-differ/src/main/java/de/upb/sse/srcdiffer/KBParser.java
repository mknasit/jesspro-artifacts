package de.upb.sse.srcdiffer;

import de.upb.sse.srcdiffer.model.kb.Statement;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;
import org.yaml.snakeyaml.constructor.Constructor;
import org.yaml.snakeyaml.representer.Representer;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class KBParser {

    public List<Statement> parseStatements(String dir) {
        List<File> statementFiles = getStatementFiles(dir);
        DumperOptions dumperOptions = new DumperOptions();
        Representer representer = new Representer(dumperOptions);
        representer.getPropertyUtils().setSkipMissingProperties(true);

        Yaml yaml = new Yaml(new Constructor(Statement.class), representer);

        List<Statement> statements = new ArrayList<>();
        for (File statementFile : statementFiles) {
            try (InputStream inputStream = new FileInputStream(statementFile)){
                Statement statement = yaml.load(inputStream);
                statements.add(statement);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        List<Statement> filteredStatements = statements.stream()
                .filter(st -> st.hasFixes() && st.hasCommits())
                .collect(Collectors.toList());

        return filteredStatements;
    }

    public Statement parseStatement(String dir) {
        File statementFile = getStatementFile(dir);
        DumperOptions dumperOptions = new DumperOptions();
        Representer representer = new Representer(dumperOptions);
        representer.getPropertyUtils().setSkipMissingProperties(true);

        Yaml yaml = new Yaml(new Constructor(Statement.class), representer);
        try (InputStream inputStream = new FileInputStream(statementFile)){
            Statement statement = yaml.load(inputStream);
            if (!statement.hasFixes() || !statement.hasCommits()) return null;

            return statement;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private List<File> getStatementFiles(String dir) {
        File[] statementDirs = new File(dir).listFiles(File::isDirectory);

        List<File> statementFiles = Arrays.stream(statementDirs)
                .map(sd -> Paths.get(sd.getAbsolutePath(), "statement.yaml").toFile())
                .filter(sd -> sd.exists())
                .collect(Collectors.toList());

        return statementFiles;
    }

    private File getStatementFile(String dir) {
        Path statementPath = Paths.get(dir, "statement.yaml");
        return statementPath.toFile();
    }
}
