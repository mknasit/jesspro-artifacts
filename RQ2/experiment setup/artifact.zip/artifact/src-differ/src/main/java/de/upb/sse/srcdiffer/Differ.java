package de.upb.sse.srcdiffer;

import de.upb.sse.srcdiffer.comparison.Comparator;
import de.upb.sse.srcdiffer.git.GitHandler;
import de.upb.sse.srcdiffer.git.VersioningHandler;
import de.upb.sse.srcdiffer.model.diff.*;
import de.upb.sse.srcdiffer.model.kb.Statement;
import de.upb.sse.srcdiffer.util.GitUtil;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class Differ {
    private final String outputPath;

    public Differ(String outputPath) {
        this.outputPath = outputPath;
    }

    public Map<String, CveDiff> diffKB(String pathToKB) {
        File[] statementDirs = new File(pathToKB).listFiles(File::isDirectory);

        List<String> statementFiles = Arrays.stream(statementDirs)
                .map(sd -> Paths.get(sd.getAbsolutePath()).toFile())
                .filter(File::exists)
                .map(File::getAbsolutePath)
                .collect(Collectors.toList());

        Map<String, CveDiff> allDiffs = new HashMap<>();
        for (String statementFile : statementFiles) {
            Map<String, CveDiff> diffs = diffStatement(statementFile);
            allDiffs.putAll(diffs);
        }
        return allDiffs;
    }

    public Map<String, CveDiff> diffStatement(String pathToStatement) {
        System.out.println("Currently processing statement " + pathToStatement);
        KBParser parser = new KBParser();
        Statement statement = parser.parseStatement(pathToStatement);

//        VersioningHandler git = new GitApiHandler();
        VersioningHandler git = new GitHandler(outputPath);
        List<FileDiff> fileDiffs = git.getDiffs(statement);

        Map<String, CveDiff> diffs = new LinkedHashMap<>();
        Comparator comparator = new Comparator();

        for (FileDiff fileDiff : fileDiffs) {
            String statementId = getStatementId(pathToStatement);

            CveDiff cveDiff = diffs.getOrDefault(statementId, new CveDiff(statementId));
            FixDiff fixDiff = cveDiff.getFixDiff(fileDiff.getFixId());

            if (fixDiff == null) {
                fixDiff = new FixDiff(fileDiff.getFixId(), fileDiff.getRepo(), Path.of(outputPath, GitUtil.getProjectName(fileDiff.getRepo())).toString());
                cveDiff.addFixDiff(fixDiff);
            }

            fixDiff.addCommitId(fileDiff.getCommitId());

            if (fileDiff.getDiffType() == DiffType.ADDED) {
                fixDiff.addAddedClass(fileDiff.getFixFilePath());
            } else if (fileDiff.getDiffType() == DiffType.REMOVED) {
                fixDiff.addRemovedClass(fileDiff.getVulFilePath());
            } else {
                ClassDiff classDiff = comparator.compare(fileDiff);
                fixDiff.addChangedClass(classDiff);
            }

            diffs.putIfAbsent(statementId, cveDiff);
        }

        return diffs;
    }

    private String getStatementId(String pathToStatementString) {
        Path pathToStatement = Path.of(pathToStatementString);

        return pathToStatement.getFileName().toString();
    }

}
