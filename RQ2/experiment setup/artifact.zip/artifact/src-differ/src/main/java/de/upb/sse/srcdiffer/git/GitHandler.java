package de.upb.sse.srcdiffer.git;

import de.upb.sse.srcdiffer.model.diff.DiffType;
import de.upb.sse.srcdiffer.model.diff.FileDiff;
import de.upb.sse.srcdiffer.model.kb.Commit;
import de.upb.sse.srcdiffer.util.GitUtil;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.diff.DiffEntry;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.ObjectReader;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.lib.TextProgressMonitor;
import org.eclipse.jgit.treewalk.CanonicalTreeParser;

import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class GitHandler extends VersioningHandler {
    private final String output;

    public GitHandler(String output) {
        this.output = output;
    }

    @Override
    protected List<FileDiff> getDiffs(Commit commit, String fixId) {
        String commitId = commit.getId();
        List<FileDiff> diffs = new ArrayList<>();

        try (Git git = cloneRepo(commit.getRepository())) {
            List<DiffEntry> gitDiffEntries = getGitDiffEntries(git, commit);
            for (DiffEntry diffEntry : gitDiffEntries) {
                String oldPath = diffEntry.getOldPath();
                String newPath = diffEntry.getNewPath();
                if (!isFileOfInterest(oldPath) && !isFileOfInterest(newPath)) continue;

                String oldFile = null;
                String newFile = null;

                if (diffEntry.getChangeType() == DiffEntry.ChangeType.ADD || diffEntry.getChangeType() == DiffEntry.ChangeType.MODIFY) {
                    newFile = getFileContent(git, GitUtil.getProjectName(commit.getRepository()), newPath, commitId);
                }
                if (diffEntry.getChangeType() == DiffEntry.ChangeType.DELETE || diffEntry.getChangeType() == DiffEntry.ChangeType.MODIFY) {
                    oldFile = getFileContent(git, GitUtil.getProjectName(commit.getRepository()), oldPath, commitId + "^1");
                }

                DiffType diffType = null;
                if (newFile == null) diffType = DiffType.REMOVED;
                else if (oldFile == null) diffType = DiffType.ADDED;
                else diffType = DiffType.CHANGED;

                FileDiff fileDiff = new FileDiff(commit.getRepository(), fixId, commit.getId(), oldPath, newPath, oldFile, newFile, diffType);
                diffs.add(fileDiff);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return diffs;
    }

    private String getFileContent(Git git, String repoName, String filePath, String commitId) {
        String fileContent = "";
        try {
            ObjectId commit = git.getRepository().resolve(commitId);
            git.checkout().setName(commit.getName()).call();
            fileContent = Files.readString(Paths.get(output, repoName, filePath));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fileContent;
    }

    private List<DiffEntry> getGitDiffEntries(Git git, Commit commit) {
        List<DiffEntry> diffEntries = new ArrayList<>();

        String commitId = commit.getId();
        try (ObjectReader reader = git.getRepository().newObjectReader()) {
            Repository repo = git.getRepository();

            ObjectId afterFix = repo.resolve(commitId + "^{tree}");
            CanonicalTreeParser afterFixTreeIterator = new CanonicalTreeParser();
            afterFixTreeIterator.reset(reader, afterFix);

            ObjectId beforeFix = repo.resolve(commitId + "^^{tree}");
            CanonicalTreeParser beforeFixTreeIterator = new CanonicalTreeParser();
            beforeFixTreeIterator.reset(reader, beforeFix);

            diffEntries = git.diff()
                    .setOldTree(beforeFixTreeIterator)
                    .setNewTree(afterFixTreeIterator)
                    .call();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return diffEntries;
    }

    private Git cloneRepo(String url) {
        File repo = Paths.get(output, GitUtil.getProjectName(url)).toFile();
        Git git = null;

        try {
            if (repo.exists()) {
                git = Git.open(repo);
            } else {
                System.out.println("Currently cloning: " + url);
                git = Git.cloneRepository()
                        .setProgressMonitor(new TextProgressMonitor(new PrintWriter(System.out)))
                        .setURI(url)
                        .setDirectory(repo)
                        .call();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return git;
    }
}
