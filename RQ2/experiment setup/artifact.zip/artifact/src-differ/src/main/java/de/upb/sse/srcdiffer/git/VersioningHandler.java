package de.upb.sse.srcdiffer.git;

import de.upb.sse.srcdiffer.model.diff.FileDiff;
import de.upb.sse.srcdiffer.model.kb.Commit;
import de.upb.sse.srcdiffer.model.kb.Fix;
import de.upb.sse.srcdiffer.model.kb.Statement;

import java.util.ArrayList;
import java.util.List;

public abstract class VersioningHandler {

    public List<FileDiff> getDiffs(List<Statement> statements) {
        List<FileDiff> diffs = new ArrayList<>();
        for (Statement statement : statements) {
            diffs.addAll(getDiffs(statement));
        }
        return diffs;
    }

    public List<FileDiff> getDiffs(Statement statement) {
        List<FileDiff> diffs = new ArrayList<>();
        if (statement == null) return diffs;

        List<Fix> fixes = statement.getFixes();
        for (Fix fix : fixes) {
            diffs.addAll(getDiffs(fix));
        }
        return diffs;
    }

    protected List<FileDiff> getDiffs(Fix fix) {
        List<FileDiff> diffs = new ArrayList<>();
        for (Commit commit : fix.getCommits()) {
            diffs.addAll(getDiffs(commit, fix.getId()));
        }
        return diffs;
    }

    protected abstract List<FileDiff> getDiffs(Commit commit, String fixId);

    protected String getRepositoryName(String repoUrl) {
        String cleanedRepoUrl = repoUrl.replace(".git", "");
        String[] splitUrl = cleanedRepoUrl.split("/");
        if (splitUrl.length < 2) return "";
        return splitUrl[splitUrl.length - 2] + "/" + splitUrl[splitUrl.length - 1];
    }

    protected boolean isFileOfInterest(String fileName) {
        String lcFileName = fileName.toLowerCase();
        if (!lcFileName.endsWith(".java")) return false;
        if (lcFileName.contains("test")) return false;
        if (lcFileName.contains("demo")) return false;
        if (lcFileName.contains("example")) return false;
        return true;
    }

}
