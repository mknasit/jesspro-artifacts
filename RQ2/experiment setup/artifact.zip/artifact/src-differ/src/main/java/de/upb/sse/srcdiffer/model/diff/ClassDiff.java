package de.upb.sse.srcdiffer.model.diff;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ClassDiff {
    private final String className;
    private final String oldClassPath;
    private final String newClassPath;
    private final DiffType diffType;
    private final List<String> addedMethods = new ArrayList<>();
    private final List<String> removedMethods = new ArrayList<>();
    private final List<String> changedMethods = new ArrayList<>();
    private final List<String> initChanges = new ArrayList<>();
    private final List<String> clinitChanges = new ArrayList<>();
    private final List<String> addedInnerClasses = new ArrayList<>();
    private final List<String> removedInnerClasses = new ArrayList<>();

    public ClassDiff(String className, String oldClassPath, String newClassPath, DiffType diffType) {
        this.className = className;
        this.oldClassPath = oldClassPath;
        this.newClassPath = newClassPath;
        this.diffType = diffType;
    }

    public void addAddedMethods(List<String> methodSignatures) {
        addedMethods.addAll(methodSignatures);
    }

    public void addRemovedMethods(List<String> methodSignatures) {
        removedMethods.addAll(methodSignatures);
    }

    public void addChangedMethods(List<String> methodSignatures) {
        changedMethods.addAll(methodSignatures);
    }

    public void addAddedMethod(String methodSignature) {
        addedMethods.add(methodSignature);
    }

    public void addRemovedMethod(String methodSignature) {
        removedMethods.add(methodSignature);
    }

    public void addChangedMethod(String methodSignature) {
        changedMethods.add(methodSignature);
    }

    public void addInitChange(String initSignature) {
        initChanges.add(initSignature);
    }

    public void addInitChanges(List<String> initSignatures) {
        initChanges.addAll(initSignatures);
    }

    public void addClinitChange(String clinitSignature) {
        clinitChanges.add(clinitSignature);
    }

    public void addClinitChanges(List<String> clinitSignatures) {
        clinitChanges.addAll(clinitSignatures);
    }

    public void addAddedInnerClass(String innerClassSignature) {
        addedInnerClasses.add(innerClassSignature);
    }

    public void addAddedInnerClasses(List<String> innerClassSignatures) {
        addedInnerClasses.addAll(innerClassSignatures);
    }

    public void addRemovedInnerClass(String innerClassSignature) {
        removedInnerClasses.add(innerClassSignature);
    }

    public void addRemovedInnerClasses(List<String> innerClassSignatures) {
        removedInnerClasses.addAll(innerClassSignatures);
    }

    public String getClassName() {
        return className;
    }

    public String getOldClassPath() {
        return oldClassPath;
    }

    public String getNewClassPath() {
        return newClassPath;
    }

    public DiffType getDiffType() {
        return diffType;
    }

    public List<String> getAddedMethods() {
        return addedMethods;
    }

    public List<String> getRemovedMethods() {
        return removedMethods;
    }

    public List<String> getChangedMethods() {
        return changedMethods;
    }

    public List<String> getInitChanges() {
        return initChanges;
    }

    public List<String> getClinitChanges() {
        return clinitChanges;
    }

    public List<String> getAddedInnerClasses() {
        return addedInnerClasses;
    }

    public List<String> getRemovedInnerClasses() {
        return removedInnerClasses;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ClassDiff classDiff = (ClassDiff) o;

        if (!Objects.equals(className, classDiff.className)) return false;
        return Objects.equals(newClassPath, classDiff.newClassPath);
    }

    @Override
    public int hashCode() {
        int result = className != null ? className.hashCode() : 0;
        result = 31 * result + (newClassPath != null ? newClassPath.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ClassDiff{" + "\n" +
                "className='" + className + '\'' + "\n" +
                ", oldClassPath='" + oldClassPath + '\'' + "\n" +
                ", newClassPath='" + newClassPath + '\'' + "\n" +
                ", diffType=" + diffType + "\n" +
                ", addedMethods=" + addedMethods + "\n" +
                ", removedMethods=" + removedMethods + "\n" +
                ", changedMethods=" + changedMethods + "\n" +
                ", initChanges=" + initChanges + "\n" +
                ", clinitChanges=" + clinitChanges + "\n" +
                ", addedInnerClasses=" + addedInnerClasses + "\n" +
                ", removedInnerClasses=" + removedInnerClasses + "\n" +
                '}';
    }
}
