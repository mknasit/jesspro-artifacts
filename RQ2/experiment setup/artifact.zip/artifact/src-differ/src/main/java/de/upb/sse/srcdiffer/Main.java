package de.upb.sse.srcdiffer;

import de.upb.sse.srcdiffer.model.diff.CveDiff;

import java.util.Map;

public class Main {

    public static void main(String[] args) {
        String pathToKB = "C:\\Users\\Stefan\\Desktop\\Hektor\\project-kb-dummy\\statements";
        String pathToStatement = "C:\\Users\\Stefan\\Desktop\\Hektor\\project-kb\\statements\\CVE-2015-6748";
        Differ differ = new Differ("repos");
        Map<String, CveDiff> diffs = differ.diffStatement(pathToStatement);

        System.out.println(diffs);
        System.out.println(diffs.size());
        System.out.println(diffs.values().iterator().next().getFixDiffs().size());
    }
}
