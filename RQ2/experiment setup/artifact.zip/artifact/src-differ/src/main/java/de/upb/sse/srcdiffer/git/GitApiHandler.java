package de.upb.sse.srcdiffer.git;

import de.upb.sse.srcdiffer.model.diff.FileDiff;
import de.upb.sse.srcdiffer.model.diff.DiffType;
import de.upb.sse.srcdiffer.model.kb.Commit;
import org.kohsuke.github.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class GitApiHandler extends VersioningHandler {
    private GitHub github;

    public GitApiHandler() {
        try {
            github = GitHubBuilder.fromPropertyFile("./.github").build();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    protected List<FileDiff> getDiffs(Commit commit, String fixId) {
        List<FileDiff> diffs = new ArrayList<>();
        String repoName = getRepositoryName(commit.getRepository());

        try {
            GHRepository repo = github.getRepository(repoName);
            GHCommit ghCommit = repo.getCommit(commit.getId());
            List<GHCommit.File> changedFiles = ghCommit.getFiles();

            for (GHCommit.File changedFile : changedFiles) {
                String fixedFile = null;
                String vulFile = null;

                String vulFilePath = changedFile.getPreviousFilename();
                String fixFilePath = changedFile.getFileName();

                if (!isFileOfInterest(fixFilePath)) continue;

                if (changedFile.getStatus().equals("added") || changedFile.getStatus().equals("modified")) {
                    GHContent fixedFileContent = repo.getFileContent(fixFilePath, ghCommit.getSHA1());
                    fixedFile = getFileContent(fixedFileContent);
                }

                if (changedFile.getStatus().equals("removed") || changedFile.getStatus().equals("modified")) {
                    GHContent vulnerableFileContent = repo.getFileContent(vulFilePath, ghCommit.getSHA1() + "^1");
                    vulFile = getFileContent(vulnerableFileContent);
                }

                DiffType diffType = null;
                if (fixedFile == null) diffType = DiffType.REMOVED;
                else if (vulFile == null) diffType = DiffType.ADDED;
                else diffType = DiffType.CHANGED;

                FileDiff fileDiff = new FileDiff(repoName, fixId, commit.getId(), vulFilePath, fixFilePath, vulFile, fixedFile, diffType);
                diffs.add(fileDiff);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return diffs;
    }

    private String getFileContent(GHContent ghContent) {
        String fixedFileContentString = "";
        try (InputStream inputStream = ghContent.read()) {
            fixedFileContentString = new BufferedReader(new InputStreamReader(inputStream)).lines().collect(Collectors.joining("\n"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fixedFileContentString;
    }

}
