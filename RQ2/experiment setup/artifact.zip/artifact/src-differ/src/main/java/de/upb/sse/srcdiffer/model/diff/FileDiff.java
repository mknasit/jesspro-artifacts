package de.upb.sse.srcdiffer.model.diff;

public class FileDiff {
    private final String repo;
    private final String fixId;
    private final String commitId;
    private final String vulFilePath;
    private final String fixFilePath;
    private final String vulClass;
    private final String fixClass;
    private final DiffType diffType;

    public FileDiff(String repo, String fixId, String commitId, String vulFilePath, String fixFilePath, String vulClass, String fixClass, DiffType diffType) {
        this.repo = repo;
        this.fixId = fixId;
        this.commitId = commitId;
        this.vulFilePath = vulFilePath;
        this.fixFilePath = fixFilePath;
        this.vulClass = vulClass;
        this.fixClass = fixClass;
        this.diffType = diffType;
    }

    public String getRepo() {
        return repo;
    }

    public String getCommitId() {
        return commitId;
    }

    public String getVulFilePath() {
        return vulFilePath;
    }

    public String getFixFilePath() {
        return fixFilePath;
    }

    public String getVulClass() {
        return vulClass;
    }

    public String getFixClass() {
        return fixClass;
    }

    public DiffType getDiffType() {
        return diffType;
    }

    public String getFixId() {
        return fixId;
    }

    @Override
    public String toString() {
        return "FileDiff{" + "\n" +
                "  fixId='" + fixId + '\'' + "\n" +
                "  repo='" + repo + '\'' + "\n" +
                ", commitId='" + commitId + '\'' + "\n" +
                ", vulFilePath='" + vulFilePath + '\'' + "\n" +
                ", diffType=" + diffType + "\n" +
                '}' + "\n";
    }
}
