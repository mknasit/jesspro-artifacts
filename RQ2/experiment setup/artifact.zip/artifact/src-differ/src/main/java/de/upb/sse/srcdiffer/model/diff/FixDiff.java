package de.upb.sse.srcdiffer.model.diff;

import java.util.ArrayList;
import java.util.List;

public class FixDiff {
    private final String id;
    private final String repo;
    private final List<String> commitIds = new ArrayList<>();
    private final List<String> addedClasses = new ArrayList<>();
    private final List<String> removedClasses = new ArrayList<>();
    private final List<ClassDiff> changedClasses = new ArrayList<>();
    private final String outputPath;

    public FixDiff(String id, String repo, String outputPath) {
        this.id = id;
        this.repo = repo;
        this.outputPath = outputPath;
    }

    public void addCommitId(String commitId) {
        if (commitIds.contains(commitId)) return;
        this.commitIds.add(commitId);
    }

    public void addAddedClass(String clazz) {
        if (addedClasses.contains(clazz)) return;
        this.addedClasses.add(clazz);
    }

    public void addRemovedClass(String clazz) {
        if (removedClasses.contains(clazz)) return;
        this.removedClasses.add(clazz);
    }

    public void addChangedClass(ClassDiff classDiff) {
        if (changedClasses.contains(classDiff)) return;
        this.changedClasses.add(classDiff);
    }

    public String getId() {
        return id;
    }

    public String getRepo() {
        return repo;
    }

    public List<String> getCommitIds() {
        return commitIds;
    }

    public String getFirstCommitId() {
        if (commitIds.size() == 0) return null;
        return commitIds.get(0);
    }

    public String getLastCommitId() {
        if (commitIds.size() == 0) return null;
        return commitIds.get(commitIds.size() - 1);
    }

    public List<String> getAddedClasses() {
        return addedClasses;
    }

    public List<String> getRemovedClasses() {
        return removedClasses;
    }

    public List<ClassDiff> getChangedClasses() {
        return changedClasses;
    }

    public String getOutputPath() {
        return outputPath;
    }

    @Override
    public String toString() {
        return "Diff{" + "\n" +
                "id='" + id + '\'' + "\n" +
                ", repo='" + repo + '\'' + "\n" +
                ", commitIds='" + commitIds + '\'' + "\n" +
                ", addedClasses=" + addedClasses + "\n" +
                ", removedClasses=" + removedClasses + "\n" +
                ", changedClasses=" + changedClasses + "\n" +
                ", outputPath=" + outputPath + "\n" +
                '}';
    }
}
