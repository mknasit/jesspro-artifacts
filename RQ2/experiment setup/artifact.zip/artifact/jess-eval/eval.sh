#!/bin/bash

# Check if the correct number of arguments is provided
if [ $# -ne 2 ]; then
    echo "Usage: $0 input_file java_application.jar"
    exit 1
fi

input_file=$1
java_application=$2

# Check if the input file exists
if [ ! -f "$input_file" ]; then
    echo "Error: Input file '$input_file' not found."
    exit 1
fi

# Check if the Java application JAR file exists
if [ ! -f "$java_application" ]; then
    echo "Error: Java application JAR file '$java_application' not found."
    exit 1
fi

# Read the file line by line and supply it to the Java application
while IFS= read -r line
do
    timeout 2h java -Xmx8g -jar "$java_application" /usr/bin/mvn 100 3 false "$line"
done < "$input_file"

# Check if the last line doesn't end with a newline character
if [ ! -z "$line" ]; then
    timeout 2h java -Xmx8g -jar "$java_application" /usr/bin/mvn 100 3 false "$line"
fi