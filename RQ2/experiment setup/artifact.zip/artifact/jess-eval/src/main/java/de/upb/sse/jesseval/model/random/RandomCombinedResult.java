package de.upb.sse.jesseval.model.random;

import de.upb.sse.jesseval.model.DirectCompilationResult;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@RequiredArgsConstructor
@Getter
@ToString
public class RandomCombinedResult {
    private final String projectName;
    private List<DirectCompilationResult> directResults = new ArrayList<>();
    private List<RandomMethodResult> slicingResults = new ArrayList<>();
    private List<RandomMethodResult> stubbingResults = new ArrayList<>();
    private List<RandomMethodResult> depsResults = new ArrayList<>();

}
