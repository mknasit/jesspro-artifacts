package de.upb.sse.jesseval.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Getter
@RequiredArgsConstructor
@AllArgsConstructor
@ToString
public class CombinedBuildResult {
    private final String projectName;
    private ProjectBuildResult slicingResults= null;
    private ProjectBuildResult stubbingResults= null;
    private ProjectBuildResult depsResults= null;
}
