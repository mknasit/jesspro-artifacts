package de.upb.sse.jesseval;

import de.upb.sse.jess.CompilerInvoker;
import de.upb.sse.jess.Jess;
import de.upb.sse.jess.configuration.JessConfiguration;
import de.upb.sse.jess.dependency.MavenDependencyResolver;
import de.upb.sse.jess.finder.PackageFinder;
import de.upb.sse.jess.finder.PomFinder;
import de.upb.sse.jesseval.comparison.BytecodeComparator;
import de.upb.sse.jesseval.comparison.MethodComparison;
import de.upb.sse.jesseval.model.*;
import de.upb.sse.jesseval.util.FileUtils;
import de.upb.sse.jesseval.util.JPUtils;
import lombok.RequiredArgsConstructor;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RequiredArgsConstructor
public class JessHandler {
    private final String projectName;
    private final Path projectPath;
    private final boolean performComparison;

    public CombinedBuildResult compileAll(String classVersion) {
        String version = classVersion.equals("unknown") ? "11" : classVersion;

        Set<String> packages = PackageFinder.findPackageRoots(projectPath.toString());

        // Slicing
        JessConfiguration slicingConfig = new JessConfiguration(false, false, true, true, false, true, version);
        ProjectBuildResult slicingResult = compileFiles(packages, Collections.emptySet(), slicingConfig);

        // Amb. Stubbing
        JessConfiguration stubbingConfig = new JessConfiguration(false, false, true, true, false, false, version);
        ProjectBuildResult stubbingResult = compileFiles(packages, Collections.emptySet(), stubbingConfig);

        // Deps
        JessConfiguration depsConfig = new JessConfiguration(false, false, true, true, false, false, version);
        Set<String> poms = PomFinder.findPomFilePaths(projectPath.toString(), false);

        MavenDependencyResolver.resolveDependencies(poms, false);
        ProjectBuildResult depsResult = compileFiles(packages, Collections.emptySet(), depsConfig);
        MavenDependencyResolver.cleanupJars();

        return new CombinedBuildResult(projectName, slicingResult, stubbingResult, depsResult);
    }

    private ProjectBuildResult compileFiles(Set<String> packages, Set<String> jars, JessConfiguration config) {
        List<String> javaFiles = FileUtils.getAllRelevantJavaFiles(projectPath.toString());

        ProjectBuildResult buildResult = new ProjectBuildResult(javaFiles.size());

        for (int i = 0; i < javaFiles.size(); i++) {

            System.out.println("------------------------------------");
            System.out.println("Compiling File " + i + " " + javaFiles.get(i) + ":");

            FileBuildResult fileBuildResult = compileMethods(javaFiles.get(i), packages, jars, config);
            buildResult.addFileBuildResult(fileBuildResult);
        }
        return buildResult;
    }

    public FileBuildResult compileMethods(String targetClass, Set<String> packages, Set<String> jars, JessConfiguration config) {
        List<String> allMethods = JPUtils.getMethods(targetClass);
        List<String> clinitChanges = JPUtils.getTypeDeclarationsWithClinitChanges(targetClass);
        List<String> initChanges = JPUtils.getTypeDeclarationsWithInitChanges(targetClass);

        FileBuildResult buildResult = new FileBuildResult(targetClass, allMethods.size() + clinitChanges.size() + initChanges.size());

        for (String method : allMethods) {
            System.out.println("Compiling Method: " + method);
            List<String> isolatedMethods = new ArrayList<>(Collections.singleton(method));

            BuildAndComparisonResult methodCompilationResult = compile(targetClass, packages, jars, config, isolatedMethods, Collections.emptyList(), Collections.emptyList());
            if (methodCompilationResult.isBuildSuccess()) buildResult.incrementCompiledMethods();
            if (methodCompilationResult.getMethodComparisons() != null) buildResult.addMethodComparisons(methodCompilationResult.getMethodComparisons());
        }


        if (!clinitChanges.isEmpty()) {
            System.out.println("Compiling <clinit>");
            BuildAndComparisonResult clinitCompilationResult = compile(targetClass, packages, jars, config, Collections.emptyList(), clinitChanges, Collections.emptyList());
            if (clinitCompilationResult.isBuildSuccess()) buildResult.incrementCompiledMethods();
            if (clinitCompilationResult.getMethodComparisons() != null) buildResult.addMethodComparisons(clinitCompilationResult.getMethodComparisons());
        }

//        if (!initChanges.isEmpty()) {
//            System.out.println("Compiling <init>");
//            BuildAndComparisonResult initCompilationResult = compile(targetClass, packages, jars, config, Collections.emptyList(), Collections.emptyList(), initChanges);
//            if (initCompilationResult.isBuildSuccess()) buildResult.incrementCompiledMethods();
//            if (initCompilationResult.getMethodComparisons() != null) buildResult.addMethodComparisons(initCompilationResult.getMethodComparisons());
//        }

        return buildResult;
    }

    private BuildAndComparisonResult compile(String targetClass, Set<String> packages, Set<String> jars, JessConfiguration config, List<String> methodsToKeep, List<String> clinit, List<String> init) {
//        if (!targetClass.endsWith("AbstractRequestContext.java")) return false;
        try {
            Jess jess = new Jess(config, packages, jars);
            jess.preSlice(targetClass, methodsToKeep, clinit, init);

            int jessResult = jess.parse(targetClass);
            boolean jessSuccess = jessResult == 0;
            if (!performComparison || !jessSuccess) return new BuildAndComparisonResult(jessSuccess);

            try {
                BytecodeComparator comp = new BytecodeComparator(CompilerInvoker.output, projectPath.toString());
                String[] splitTargetClass = targetClass.replace("\\", "/").replace(".java", "").split("/");
                String targetClassName = splitTargetClass[splitTargetClass.length - 1];
                List<MethodComparison> comparisons = comp.compareMethods(targetClassName, !clinit.isEmpty());
                return new BuildAndComparisonResult(true, comparisons);
            } catch (Exception e) {
                return new BuildAndComparisonResult(true);
            }

        } catch (Throwable e) {
            e.printStackTrace();
            return new BuildAndComparisonResult(false);
        }
    }

}
