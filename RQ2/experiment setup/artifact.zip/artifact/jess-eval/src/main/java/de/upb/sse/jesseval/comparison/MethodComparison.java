package de.upb.sse.jesseval.comparison;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.File;
import java.nio.file.Path;

@AllArgsConstructor
@Getter
public class MethodComparison {
    private String className;
    private final String methodName;
    private final int levenshteinDistance;
    private final double normalizedLevenshteinDistance;
    private final boolean equal;
    private final boolean wildcardEqual;

    private final transient String actualContent;
    private final transient String expectedContent;

    @Setter
    private String generatedSourceFilePath = "";
    @Setter
    private String groundTruthSourceFilePath = "";

    public MethodComparison(String methodName, String actualContent, String expectedContent, int levenshteinDistance, double normalizedLevenshteinDistance) {
        this("unknown", methodName, actualContent, expectedContent, levenshteinDistance, normalizedLevenshteinDistance);
    }

    public MethodComparison(String className, String methodName, String actualContent, String expectedContent, int levenshteinDistance, double normalizedLevenshteinDistance) {
        this.className = className;
        this.methodName = methodName;
        this.levenshteinDistance = levenshteinDistance;
        this.normalizedLevenshteinDistance = normalizedLevenshteinDistance;
        this.equal = isEqual(actualContent, expectedContent);
        this.wildcardEqual = isWildcardEqual(actualContent, expectedContent);

        this.actualContent = actualContent;
        this.expectedContent = expectedContent;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public boolean isEqual(String actualContent, String expectedContent) {
        return actualContent.equals(expectedContent);
    }

    public boolean isWildcardEqual(String actualContent, String expectedContent) {
        String anonClassReplaceRegex = "\\$\\d+\\(";
        String bridgeMethodReplaceRegex = "\\$\\d\\d\\d";
        String wildcardActual = actualContent.replaceAll(anonClassReplaceRegex, "\\$x(").replaceAll(bridgeMethodReplaceRegex, "\\$xxx(");
        String wildcardExpected = expectedContent.replaceAll(anonClassReplaceRegex, "\\$x(").replaceAll(bridgeMethodReplaceRegex, "\\$xxx(");;

        return wildcardActual.equals(wildcardExpected);
    }

    public String getEquality() {
        if (isEqual()) {
            return "MethodComparison{" + '\n' +
                    "className='" + className + '\'' + '\n' +
                    ", methodName='" + methodName + '\'' + '\n' +
                    ", equal='" + isEqual() + '\'' + '\n' +
                    '}';
        } else {
            return "--- ActualContent ---" + "\n\t" + actualContent + '\n' +
                    "---ExpectedContent ---" + "\n\t" + expectedContent + '\n' +
                    "-----------------------------------" + '\n' +
                    "Gen: " + generatedSourceFilePath + '\n' +
                    "GT: " + groundTruthSourceFilePath + '\n';
        }
    }

    @Override
    public String toString() {
        return "MethodComparison{" +
                "className='" + className + '\'' +
                ", methodName='" + methodName + '\'' +
                ", levenshteinDistance=" + levenshteinDistance +
                ", normalizedLevenshteinDistance=" + normalizedLevenshteinDistance +
                ", equal=" + equal +
                ", wildcardEqual=" + wildcardEqual +
                '}';
    }
}
