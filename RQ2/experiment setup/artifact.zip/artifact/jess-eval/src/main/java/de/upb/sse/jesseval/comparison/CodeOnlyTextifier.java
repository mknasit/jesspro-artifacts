package de.upb.sse.jesseval.comparison;

import org.objectweb.asm.Opcodes;
import org.objectweb.asm.TypePath;
import org.objectweb.asm.util.Textifier;

public class CodeOnlyTextifier extends Textifier {

    public CodeOnlyTextifier() {
        super(Opcodes.ASM9);
    }

    @Override
    public Textifier visitAnnotation(final String descriptor, final boolean visible) {
        // do not print anything
        return createTextifier();
    }

    @Override
    public Textifier visitParameterAnnotation(final int parameter, final String descriptor, final boolean visible) {
        // do not print anything
        return createTextifier();
    }

    @Override
    public Textifier visitAnnotableParameterCount(int parameterCount, boolean visible) {
        // do not print anything
        return createTextifier();
    }

    @Override
    public Textifier visitTypeAnnotation(int typeRef, TypePath typePath, String descriptor, boolean visible) {
        // do not print anything
        return createTextifier();
    }

    @Override
    public void visitMaxs(int maxStack, int maxLocals) {
        // do not print anything
    }

    @Override
    public void visitFrame(int type, int numLocal, Object[] local, int numStack, Object[] stack) {
        // do not print anything
    }

}
