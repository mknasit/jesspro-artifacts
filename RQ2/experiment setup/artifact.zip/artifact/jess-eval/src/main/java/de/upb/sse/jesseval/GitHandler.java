package de.upb.sse.jesseval;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.lib.Ref;
import org.eclipse.jgit.lib.TextProgressMonitor;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevWalk;

import java.io.*;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

public class GitHandler {
    private final String output;

    public GitHandler(String output) {
        this.output = output;
    }

    public String cloneRepo(String url) throws GitAPIException{
        File repo = Paths.get(output, getRepoName(url)).toFile();
        if (repo.exists()) return getRepoName(url);

        System.out.println("Currently cloning: " + url);
        try (Git git = Git.cloneRepository()
                .setProgressMonitor(new TextProgressMonitor(new PrintWriter(System.out)))
                .setURI(url)
                .setDirectory(repo)
                .call()) {

            return getRepoName(url);
        }
    }

    public String getRepoName(String url) {
        String[] splitUrl = url.split("/");
        return splitUrl[splitUrl.length - 2] + "_" + splitUrl[splitUrl.length - 1];
    }

    private void checkoutNextTag(Git git) throws GitAPIException {
        List<Ref> tags = git.tagList().call();

        // Sort tags based on their creation date
        RevWalk walk = new RevWalk(git.getRepository());
        tags.sort((tag1, tag2) -> {
            RevCommit c1 = null;
            RevCommit c2 = null;

            try {
                c1 = walk.parseCommit(tag1.getObjectId());
                walk.parseBody(c1);
                Date d1 = c1.getAuthorIdent().getWhen();

                c2 = walk.parseCommit(tag2.getObjectId());
                walk.parseBody(c2);
                Date d2 = c2.getAuthorIdent().getWhen();

                return d1.compareTo(d2);

            } catch (IOException e) {
                e.printStackTrace();
            }
            return 0;
        });

        if (!tags.isEmpty()) {
            Ref recentRef = tags.get(tags.size() - 1);
            git.checkout().setName(recentRef.getName()).call();
        }
    }

}
