package de.upb.sse.jesseval.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor
public class DirectCompilationResult {
    private String className;
    private final String methodSignature;
    private final boolean clinit;
    private final boolean buildSuccess;
    private final long compilationTimeMs;
}
