package de.upb.sse.jesseval.util;

import com.github.javaparser.ParseProblemException;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import de.upb.sse.jesseval.Main;
import de.upb.sse.jesseval.model.random.ClassMethodPair;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class JPUtils {

    public static List<String> getMethods(String targetClass)  {
        try {
            CompilationUnit root = StaticJavaParser.parse(Paths.get(targetClass));
            List<CallableDeclaration> allMethodDeclarations = root.findAll(CallableDeclaration.class);

            List<String> nonAnonymousMethodDeclarationSignatures = allMethodDeclarations.stream()
                    .filter(md -> {
                        Optional<Node> parentNodeOpt = md.getParentNode();
                        if (parentNodeOpt.isEmpty()) return true;

                        Node parentNode = parentNodeOpt.get();
                        if (!(parentNode instanceof ObjectCreationExpr)) return true;

                        return false;
                    })
                    .map(md -> md.getSignature().asString())
                    .collect(Collectors.toList());

            return nonAnonymousMethodDeclarationSignatures;
        } catch (IOException | ParseProblemException e) {
            return new ArrayList<>();
        }
    }

    public static List<ClassMethodPair> getClassMethodPairs(String targetClass) {
        try {
            CompilationUnit root = StaticJavaParser.parse(Paths.get(targetClass));
            List<CallableDeclaration> allMethodDeclarations = root.findAll(CallableDeclaration.class);

            // keep only the class method pairs with at least 5 lines of body length
            List<CallableDeclaration> suitableMethodDeclarations = allMethodDeclarations.stream()
                    .filter(cd -> cd.getRange().isPresent())
                    .filter(cd -> cd.getRange().get().end.line - cd.getRange().get().begin.line >= (Main.MINIMUM_LOC + 2))
                    .collect(Collectors.toList());

            List<ClassMethodPair> nonAnonymousClassMethodPairs = suitableMethodDeclarations.stream()
                    .filter(md -> {
                        Optional<Node> parentNodeOpt = md.getParentNode();
                        if (parentNodeOpt.isEmpty()) return true;

                        Node parentNode = parentNodeOpt.get();
                        if (!(parentNode instanceof ObjectCreationExpr)) return true;

                        return false;
                    })
                    .map(md -> new ClassMethodPair(targetClass, md.getSignature().asString(), md, false))
                    .collect(Collectors.toList());

//            List<String> typeDeclarationsWithClinitChanges = getTypeDeclarationsWithClinitChanges(targetClass);
//            typeDeclarationsWithClinitChanges.stream()
//                    .map(td -> new ClassMethodPair(targetClass, td, null, true))
//                    .forEach(nonAnonymousClassMethodPairs::add);

            return nonAnonymousClassMethodPairs;
        } catch (IOException | ParseProblemException e) {
            return new ArrayList<>();
        }
    }

    public static List<String> getTypeDeclarationsWithClinitChanges(String targetClass) {
        try {
            CompilationUnit root = StaticJavaParser.parse(Paths.get(targetClass));
            List<TypeDeclaration> allTypeDeclarations = root.findAll(TypeDeclaration.class);

            return allTypeDeclarations.stream()
                    .filter(JPUtils::hasClinitChanges)
                    .map(JPUtils::getClassSignature)
                    .collect(Collectors.toList());
        } catch (IOException | ParseProblemException e) {
            return new ArrayList<>();
        }
    }

    public static List<String> getTypeDeclarationsWithInitChanges(String targetClass) {
        try {
            CompilationUnit root = StaticJavaParser.parse(Paths.get(targetClass));
            List<TypeDeclaration> allTypeDeclarations = root.findAll(TypeDeclaration.class);

            return allTypeDeclarations.stream()
                    .filter(JPUtils::hasInitChanges)
                    .map(JPUtils::getClassSignature)
                    .collect(Collectors.toList());
        } catch (IOException | ParseProblemException e) {
            return new ArrayList<>();
        }
    }

    private static String getClassSignature(TypeDeclaration<?> typeDec) {
        StringBuilder builder = new StringBuilder();
        Optional<ClassOrInterfaceDeclaration> parentClassOpt = typeDec.findAncestor(ClassOrInterfaceDeclaration.class);
        while (parentClassOpt.isPresent()) {
            ClassOrInterfaceDeclaration parentClass = parentClassOpt.get();
            builder.append(parentClass.getNameAsString());
            builder.append(".");
            parentClassOpt = parentClass.findAncestor(ClassOrInterfaceDeclaration.class);
        }
        builder.append(typeDec.getNameAsString());
        return builder.toString();
    }

    private static boolean hasClinitChanges(TypeDeclaration<?> typeDec) {
        List<InitializerDeclaration> initializers = typeDec.findAll(InitializerDeclaration.class);
        List<FieldDeclaration> fields = typeDec.findAll(FieldDeclaration.class);

        for (InitializerDeclaration initializer : initializers) {
            if (initializer.isStatic()) return true;
        }

        for (FieldDeclaration field : fields) {
            if (field.isStatic()) return true;
        }

        return false;
    }

    private static boolean hasInitChanges(TypeDeclaration<?> typeDec) {
        List<ConstructorDeclaration> constructorDeclarations = typeDec.findAll(ConstructorDeclaration.class);

        return constructorDeclarations.isEmpty();
    }
}
