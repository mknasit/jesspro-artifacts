package de.upb.sse.jesseval;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import de.upb.sse.jess.CompilerInvoker;
import de.upb.sse.jess.Jess;
import de.upb.sse.jess.configuration.JessConfiguration;
import de.upb.sse.jess.finder.PackageFinder;
import de.upb.sse.jesseval.build.MavenInvoker;
import de.upb.sse.jesseval.comparison.BytecodeComparator;
import de.upb.sse.jesseval.comparison.MethodComparison;
import de.upb.sse.jesseval.model.Diff;
import de.upb.sse.jesseval.model.random.RandomCombinedResult;
import de.upb.sse.jesseval.util.FileUtils;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public class Main {
    public static String REPOS_FILE = "input/repos2.txt";
//    public static String REPOS_FILE = "input/all_repos_seart.txt";
    public static String REPOS_OUTPUT = "repos";
    public static String MAVEN_PATH = "C:/Program Files/Java/apache-maven-3.8.4/bin/mvn.cmd";
    public static int COMPILATION_AMOUNT = 10;
    public static int MINIMUM_LOC = 3;
    public static boolean CLEANUP_REPOS = false;
    public static boolean RUN_MAVEN = true;
    public static boolean BATCH_DIFF_MODE = false;

    public static void main(String[] args) {
        if (args.length > 0) MAVEN_PATH = args[0];
        if (args.length > 1) COMPILATION_AMOUNT = Integer.parseInt(args[1]);
        if (args.length > 2) MINIMUM_LOC = Integer.parseInt(args[2]);
        if (args.length > 3) CLEANUP_REPOS = Boolean.parseBoolean(args[3]);
        if (args.length > 4) RUN_MAVEN = Boolean.parseBoolean(args[4]);
        if (args.length > 5) BATCH_DIFF_MODE = Boolean.parseBoolean(args[5]);

        if (BATCH_DIFF_MODE) {
            diffMode();
            return;
        }

        List<String> repoUrls = args.length > 6 ? List.of(args[6]) : FileUtils.readFileLineByLine(REPOS_FILE);
        GitHandler git = new GitHandler(REPOS_OUTPUT);

        Logger logger = new Logger(new File("logs/builds.json"));
        Logger singleLogger = new Logger(new File("logs/single-builds.json"));
        List<RandomCombinedResult> allBuildResults = new ArrayList<>();
        for (String repoUrl : repoUrls) {
            try {
                String repoName = git.cloneRepo(repoUrl);
                RandomCombinedResult combinedBuildResult = runEvaluation(repoName);
                allBuildResults.add(combinedBuildResult);

                Gson gson = new Gson();
                String json = gson.toJson(combinedBuildResult);
                singleLogger.log(json);

                if (CLEANUP_REPOS) {
                    org.apache.commons.io.FileUtils.deleteDirectory(new File(REPOS_OUTPUT));
                }

            } catch (Throwable e) {
                e.printStackTrace();
            }
        }

        Gson gson = new Gson();
        String json = gson.toJson(allBuildResults);
        logger.log(json);
    }

    public static RandomCombinedResult runEvaluation(String repoName) {
        System.out.println("########## Running pipeline for " + repoName + " " + "##########");
        Path projectPath = Paths.get(REPOS_OUTPUT, repoName);

        boolean buildSuccess = false;
        if (RUN_MAVEN) {
            MavenInvoker mvnInvoker = new MavenInvoker();
            buildSuccess = mvnInvoker.build(projectPath.toString());
        }
//        boolean buildSuccess = true;

        String translatedClassVersion = "unknown";
        if (buildSuccess || !RUN_MAVEN) {
            List<String> classFiles = FileUtils.getAllRelevantClassFiles(projectPath.toString());
            VersionIdentifier versionIdentifier = new VersionIdentifier();
            int classVersion = versionIdentifier.getNonConflictingVersionInformation(classFiles);
            // Java compiler 17 only supports down to target level 1.7
            if (classVersion > 0 && classVersion < 52) classVersion = 52;
            translatedClassVersion = versionIdentifier.translateVersion(classVersion);
        }

        boolean performComparison = (buildSuccess || !RUN_MAVEN) && !translatedClassVersion.equals("unknown");
//        boolean performComparison = false;
//        JessHandler jessHandler = new JessHandler(repoName, projectPath, performComparison);
        RandomJessHandler jessHandler = new RandomJessHandler(repoName, projectPath, performComparison, COMPILATION_AMOUNT);
        RandomCombinedResult combinedBuildResult = jessHandler.compileAll(translatedClassVersion);
        return combinedBuildResult;
    }

    public static void diffMode() {
        try {
            File diffLog = new File("logs/diffs.json");
            if (diffLog.exists()) diffLog.delete();
            Logger diffLogger = new Logger(new File("logs/diffs.json"));
            Gson gson = new Gson();
            String json = new String(Files.readAllBytes(Paths.get("input/diffs.json")));
            List<Diff> diffs = gson.fromJson(json, new TypeToken<List<Diff>>() {}.getType());
            List<Diff> remainingDiffs = new ArrayList<>();

            for (Diff diff : diffs) {
                System.out.println("----------------------------------------");
                System.out.println(diff.getProject());
                System.out.println(diff.getClassName());
                System.out.println(diff.getMethodSignature());

                Path projectPath = Path.of("repos", diff.getProject());
                String targetClass = diff.getClassName();
                String methodSignature = diff.getMethodSignature();

                if (!new File(targetClass).exists()) {
                    remainingDiffs.add(diff);
                    continue;
                }

                String translatedClassVersion = "unknown";
                List<String> classFiles = FileUtils.getAllRelevantClassFiles(projectPath.toString());
                VersionIdentifier versionIdentifier = new VersionIdentifier();
                int classVersion = versionIdentifier.getNonConflictingVersionInformation(classFiles);
                if (classVersion > 0 && classVersion < 52) classVersion = 52;
                translatedClassVersion = versionIdentifier.translateVersion(classVersion);
                if (translatedClassVersion.equals("unknown")) translatedClassVersion = null;
                System.out.println(translatedClassVersion);

                JessConfiguration config = new JessConfiguration(false, false, true,
                        true, false, true, translatedClassVersion);

                Set<String> packages = PackageFinder.findPackageRoots(projectPath.toString());
                Jess jess = new Jess(config, packages, Collections.emptyList());
                jess.preSlice(targetClass, Collections.singletonList(methodSignature), Collections.emptyList(), Collections.emptyList());
                int jessResult = jess.parse(targetClass);

                if (jessResult != 0) {
                    remainingDiffs.add(diff);
                    continue;
                }

                BytecodeComparator comp = new BytecodeComparator(CompilerInvoker.output, projectPath.toString());
                String[] splitTargetClass = targetClass.replace("\\", "/").replace(".java", "").split("/");
                String targetClassName = splitTargetClass[splitTargetClass.length - 1];
                List<MethodComparison> comparisons = comp.compareMethods(targetClassName, false);
//            System.out.println(comparisons);



                comparisons.forEach(com -> {
                    if (com.isEqual()) {
                        System.out.println("equal");
                        return;
                    } else if (com.isWildcardEqual()) {
                        diff.setWildcardEqual(true);
                        System.out.println("wildcard equal");
                    } else {
//                        System.out.println(com.getNormalizedLevenshteinDistance());
//                        System.out.println(com.getEquality());
                        System.out.println("not equal");
                    }

                    remainingDiffs.add(diff);
                });
            }


            diffLogger.log(gson.toJson(remainingDiffs));
        } catch (Exception e) {

        }

    }
}
