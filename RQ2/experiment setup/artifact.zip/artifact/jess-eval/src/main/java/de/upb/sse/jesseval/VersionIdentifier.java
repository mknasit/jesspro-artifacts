package de.upb.sse.jesseval;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.tree.ClassNode;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Random;

public class VersionIdentifier {

    public int identifyVersion(String filePath) {
        if (!filePath.endsWith(".class")) return -1;
        File classFile = new File(filePath);
        if (!classFile.exists()) return -1;

        try {
            InputStream is = new FileInputStream(classFile);
            ClassReader reader = new ClassReader(is);
            ClassNode cn = new ClassNode();
            reader.accept(cn, ClassReader.SKIP_DEBUG);
            return cn.version;
        } catch (Exception e) {
            return -1;
        }
    }

    public int getNonConflictingVersionInformation(List<String> classFiles) {
        int tests = Math.min(classFiles.size(), 5);
        int version = 0;

        for (int i = 0; i < tests; i++) {
            Random rand = new Random();
            String randomClass = classFiles.get(rand.nextInt(classFiles.size()));
            int identifiedVersion = identifyVersion(randomClass);

            if (version == 0) version = identifiedVersion;
            if (version != identifiedVersion) return -1;
        }
        return version;
    }

    public String translateVersion(int version) {
        switch (version) {
            case 55: return "11";
            case 54: return "10";
            case 53: return "9";
            case 52: return "1.8";
            case 51: return "1.7";
            case 50: return "1.6";
            case 49: return "1.5";
            default: return "unknown";
        }
    }
}
