package de.upb.sse.jesseval.model;

import de.upb.sse.jesseval.comparison.MethodComparison;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Getter
@RequiredArgsConstructor
@ToString
public class FileBuildResult {
    private final String fileName;
    private final int totalMethods;
    private int compiledMethods = 0;
    private final List<MethodComparison> methodComparisons = new ArrayList<>();

    public void incrementCompiledMethods() {
        this.compiledMethods++;
    }

    public void addMethodComparisons(Collection<MethodComparison> methodComparisons) {
        this.methodComparisons.addAll(methodComparisons);
    }
}
