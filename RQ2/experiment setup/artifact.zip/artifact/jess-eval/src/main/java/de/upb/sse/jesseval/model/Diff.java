package de.upb.sse.jesseval.model;

import lombok.Data;

@Data
public class Diff {
    private String project;
    private String className;
    private String methodSignature;
    private String nld;
    private boolean wildcardEqual;
}
