package de.upb.sse.jesseval;

import de.upb.sse.jess.CompilerInvoker;
import de.upb.sse.jess.Jess;
import de.upb.sse.jess.configuration.JessConfiguration;
import de.upb.sse.jess.dependency.MavenDependencyResolver;
import de.upb.sse.jess.finder.JarFinder;
import de.upb.sse.jess.finder.PackageFinder;
import de.upb.sse.jess.finder.PomFinder;
import de.upb.sse.jess.stats.StubbingStats;
import de.upb.sse.jesseval.build.JavacInvoker;
import de.upb.sse.jesseval.comparison.BytecodeComparator;
import de.upb.sse.jesseval.comparison.MethodComparison;
import de.upb.sse.jesseval.model.DirectCompilationResult;
import de.upb.sse.jesseval.model.random.ClassMethodPair;
import de.upb.sse.jesseval.model.random.RandomCombinedResult;
import de.upb.sse.jesseval.model.random.RandomMethodResult;
import de.upb.sse.jesseval.util.FileUtils;
import de.upb.sse.jesseval.util.JPUtils;
import lombok.RequiredArgsConstructor;

import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@RequiredArgsConstructor
public class RandomJessHandler {
    private final Random rand = new Random(1234);

    private final String projectName;
    private final Path projectPath;
    private final boolean performComparison;
    private final int compilationAmount;

    public RandomCombinedResult compileAll(String classVersion) {
        String version = classVersion.equals("unknown") ? null : classVersion;

        List<ClassMethodPair> allClassMethodPairs = getAllClassMethodPairs();
        List<ClassMethodPair> randomClassMethodPairs = getRandomClassMethodPairs(allClassMethodPairs);

//        List<DirectCompilationResult> directResult = new ArrayList<>();
//        List<RandomMethodResult> stubbingResult = new ArrayList<>();
//        List<RandomMethodResult> depsResult = new ArrayList<>();


        // Direct File compilation
        List<DirectCompilationResult> directResult = compilePairsDirectlyUsingJavac(randomClassMethodPairs);


        Set<String> packages = PackageFinder.findPackageRoots(projectPath.toString());

        // Slicing
        JessConfiguration slicingConfig = new JessConfiguration(false, false, true, true, false, true, version);
        List<RandomMethodResult> slicingResult = compilePairs(randomClassMethodPairs, packages, Collections.emptySet(), slicingConfig);

        // Amb. Stubbing
        JessConfiguration stubbingConfig = new JessConfiguration(false, false, true, true, false, false, version);
        List<RandomMethodResult> stubbingResult = compilePairs(randomClassMethodPairs, packages, Collections.emptySet(), stubbingConfig);

//        // Deps
//        List<RandomMethodResult> depsResult = new ArrayList<>();

        JessConfiguration depsConfig = new JessConfiguration(false, false, true, true, false, false, version);
        Set<String> poms = PomFinder.findPomFilePaths(projectPath.toString(), false);
        System.out.println("Poms: " + poms.size());
        MavenDependencyResolver.resolveDependencies(poms, true);
//        old:
//        Set<String> jars = MavenDependencyResolver.getJars();
//        from kb-compiler study:
        Set<String> jars = JarFinder.find(Jess.JAR_DIRECTORY);
        List<RandomMethodResult> depsResult = compilePairs(randomClassMethodPairs, packages, jars, depsConfig);
        MavenDependencyResolver.cleanupJars();

        return new RandomCombinedResult(projectName, directResult, slicingResult, stubbingResult, depsResult);
    }

    private List<RandomMethodResult> compilePairs(List<ClassMethodPair> pairs, Set<String> packages, Set<String> jars, JessConfiguration config) {
        return pairs.stream()
                .map(pair -> compile(pair, packages, jars, config))
                .collect(Collectors.toList());
    }

    private RandomMethodResult compile(ClassMethodPair classMethodPair, Set<String> packages, Set<String> jars, JessConfiguration config) {
        String targetClass = classMethodPair.getClassFile();
        String methodSignature = classMethodPair.getMethodSignature();
        boolean isClinit = classMethodPair.isClinit();

        System.out.println("Compiling: " + targetClass + " --- " + methodSignature);
        try {

            Jess jess = new Jess(config, packages, jars);
            long startTime = System.nanoTime();
            if (!isClinit) {
                jess.preSlice(targetClass, Collections.singletonList(methodSignature), Collections.emptyList(), Collections.emptyList());
            } else {
                jess.preSlice(targetClass, Collections.emptyList(), Collections.singletonList(methodSignature), Collections.emptyList());
            }

            int jessResult = jess.parse(targetClass);
            long endTime = System.nanoTime();
            long compilationTime = endTime - startTime;
            long compilationTimeMs = TimeUnit.NANOSECONDS.toMillis(compilationTime);
            boolean jessSuccess = jessResult == 0;

            StubbingStats stubbingStats = jess.getStubbingStats();
            if (!performComparison || !jessSuccess) return new RandomMethodResult(targetClass, methodSignature, isClinit, jessSuccess, compilationTimeMs, stubbingStats, Collections.emptyList());

            try {
                BytecodeComparator comp = new BytecodeComparator(CompilerInvoker.output, projectPath.toString());
                String[] splitTargetClass = targetClass.replace("\\", "/").replace(".java", "").split("/");
                String targetClassName = splitTargetClass[splitTargetClass.length - 1];
                List<MethodComparison> comparisons = comp.compareMethods(targetClassName, isClinit);
                return new RandomMethodResult(targetClass, methodSignature, isClinit, jessSuccess, compilationTimeMs, stubbingStats, comparisons);
            } catch (Exception e) {
                return new RandomMethodResult(targetClass, methodSignature, isClinit, jessSuccess, compilationTimeMs, stubbingStats, Collections.emptyList());
            }

        } catch (Throwable e) {
            e.printStackTrace();
            return new RandomMethodResult(targetClass, methodSignature, isClinit, false, 0, new StubbingStats(), Collections.emptyList());
        }
    }

    private List<DirectCompilationResult> compilePairsDirectlyUsingJavac(List<ClassMethodPair> pairs) {
        return pairs.stream()
                .map(pair -> compileDirectlyUsingJavac(pair))
                .collect(Collectors.toList());
    }

    private DirectCompilationResult compileDirectlyUsingJavac(ClassMethodPair classMethodPair) {
        String targetClass = classMethodPair.getClassFile();
        String methodSignature = classMethodPair.getMethodSignature();
        boolean isClinit = classMethodPair.isClinit();

        System.out.println("Directly Compiling via javac: " + targetClass + " --- " + methodSignature);
        try {
            long startTime = System.nanoTime();
            boolean compilationResult = JavacInvoker.compileFile(targetClass);
            long endTime = System.nanoTime();
            long compilationTime = endTime - startTime;
            long compilationTimeMs = TimeUnit.NANOSECONDS.toMillis(compilationTime);
            return new DirectCompilationResult(targetClass, methodSignature, isClinit, compilationResult, compilationTimeMs);
        } catch (Throwable e) {
            e.printStackTrace();
            return new DirectCompilationResult(targetClass, methodSignature, isClinit, false, 0);
        }
    }

    private List<ClassMethodPair> getAllClassMethodPairs() {
        List<String> javaFiles = FileUtils.getAllRelevantJavaFiles(projectPath.toString());
        List<ClassMethodPair> classMethodPairs = javaFiles.stream().flatMap(jf -> JPUtils.getClassMethodPairs(jf).stream()).collect(Collectors.toList());
        return classMethodPairs;
    }

    private List<ClassMethodPair> getRandomClassMethodPairs(List<ClassMethodPair> allPairs) {
        if (allPairs.size() <= compilationAmount) return allPairs;

        List<ClassMethodPair> randomPairs = new ArrayList<>();
        int collisions = 0;
        for (int i = 0; i < compilationAmount; i++) {
            int randomIdx = rand.nextInt(allPairs.size());
            ClassMethodPair randomPair = allPairs.get(randomIdx);
            if (randomPairs.contains(randomPair)) {
                i--;
                collisions++;
                if (collisions > compilationAmount) break;

                continue;
            }

            randomPairs.add(randomPair);
        }

        return randomPairs;
    }
}
