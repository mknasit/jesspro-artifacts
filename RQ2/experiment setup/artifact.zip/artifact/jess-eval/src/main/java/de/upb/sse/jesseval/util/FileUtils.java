package de.upb.sse.jesseval.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FileUtils {

    public static List<String> readFileLineByLine(String filePath) {
        List<String> fileContent = new ArrayList<>();

        File file = new File(filePath);
        if (!file.exists()) return fileContent;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;

            while ((line = br.readLine()) != null) {
                fileContent.add(line);
            }
        } catch (Exception ignored) {

        }

        return fileContent;
    }

    public static List<String> getAllRelevantJavaFiles(String dir) {
        List<String> javaFiles = new ArrayList<>();
        try {
            javaFiles = Files.find(Paths.get(dir), 999,
                            (p, bfa) -> bfa.isRegularFile() &&
                                    p.getFileName().toString().matches(".*\\.java") &&
                                    !p.getFileName().toString().contains("package-info") &&
                                    !p.getFileName().toString().contains("module-info") &&
                                    !p.toString().contains("test")
                    ).map(Path::toString)
                    .collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return javaFiles;
    }

    public static List<String> getAllRelevantClassFiles(String dir) {
        List<String> classFiles = new ArrayList<>();
        try {
            classFiles = Files.find(Paths.get(dir), 999,
                            (p, bfa) -> bfa.isRegularFile() &&
                                    p.getFileName().toString().matches(".*\\.class") &&
                                    !p.getFileName().toString().contains("package-info") &&
                                    !p.getFileName().toString().contains("module-info") &&
                                    !p.toString().contains("test")
                    ).map(Path::toString)
                    .collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return classFiles;
    }
}
