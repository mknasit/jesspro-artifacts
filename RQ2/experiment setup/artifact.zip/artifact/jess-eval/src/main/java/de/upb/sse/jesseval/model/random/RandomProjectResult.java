package de.upb.sse.jesseval.model.random;

import de.upb.sse.jesseval.comparison.MethodComparison;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
@Getter
@ToString
public class RandomProjectResult {
    private final int totalClasses;
    private final int totalMethods;
    private final int compiledMethods;
    private final List<MethodComparison> methodComparisons = new ArrayList<>();
}
