package de.upb.sse.jesseval.model.random;


import de.upb.sse.jess.stats.StubbingStats;
import de.upb.sse.jesseval.comparison.MethodComparison;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

import java.util.List;

@RequiredArgsConstructor
@Getter
@ToString
public class RandomMethodResult {
    private final String className;
    private final String methodSignature;
    private final boolean clinit;
    private final boolean buildSuccess;
    private final long compilationTimeMs;
    private final StubbingStats stubbingStats;
    private final List<MethodComparison> methodComparisons;
}
