package de.upb.sse.jesseval.model;

import de.upb.sse.jesseval.comparison.MethodComparison;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Getter
@ToString
@RequiredArgsConstructor
public class BuildAndComparisonResult {
    private final boolean buildSuccess;
    private final List<MethodComparison> methodComparisons;

    public BuildAndComparisonResult(boolean buildSuccess) {
        this(buildSuccess, new ArrayList<>());
    }

    public void addMethodComparison(MethodComparison methodComparison) {
        this.methodComparisons.add(methodComparison);
    }

    public void addMethodComparisons(Collection<MethodComparison> methodComparisons) {
        this.methodComparisons.addAll(methodComparisons);
    }

}
