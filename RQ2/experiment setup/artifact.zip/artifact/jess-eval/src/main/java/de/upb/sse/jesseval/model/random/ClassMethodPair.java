package de.upb.sse.jesseval.model.random;

import com.github.javaparser.ast.body.CallableDeclaration;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Getter
@RequiredArgsConstructor
@ToString
@EqualsAndHashCode
public class ClassMethodPair {
    private final String classFile;
    private final String methodSignature;
    private final CallableDeclaration<?> methodContent;
    private final boolean clinit;
}
