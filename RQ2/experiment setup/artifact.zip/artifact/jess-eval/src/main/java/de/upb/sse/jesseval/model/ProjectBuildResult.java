package de.upb.sse.jesseval.model;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;

@Getter
@RequiredArgsConstructor
@ToString
public class ProjectBuildResult {
    private final int totalFiles;
    private List<FileBuildResult> fileBuildResults = new ArrayList<>();

    public void addFileBuildResult(FileBuildResult fbr) {
        fileBuildResults.add(fbr);
    }
}
