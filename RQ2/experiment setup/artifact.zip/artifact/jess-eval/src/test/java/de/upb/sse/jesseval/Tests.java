package de.upb.sse.jesseval;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import de.upb.sse.jess.CompilerInvoker;
import de.upb.sse.jess.Jess;
import de.upb.sse.jess.configuration.JessConfiguration;
import de.upb.sse.jess.finder.PackageFinder;
import de.upb.sse.jesseval.comparison.BytecodeComparator;
import de.upb.sse.jesseval.comparison.MethodComparison;
import de.upb.sse.jesseval.model.Diff;
import de.upb.sse.jesseval.util.FileUtils;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class Tests {

    @Test
    void test1() throws IOException {
        Gson gson = new Gson();
        String json = new String(Files.readAllBytes(Paths.get("input/diffs.json")));
        List<Diff> diffs = gson.fromJson(json, new TypeToken<List<Diff>>() {}.getType());
        Diff diff = diffs.get(22); //36


        Path projectPath = Path.of("repos", "linlinjava_litemall");
        String targetClass = "repos/linlinjava_litemall/litemall-db/src/main/java/org/linlinjava/litemall/db/domain/LitemallGoodsSpecification.java";
        String methodSignature = "getEscapedColumnName()";
//
//        Path projectPath = Path.of("repos", diff.getProject());
//        String targetClass = diff.getClassName();
//        String methodSignature = diff.getMethodSignature();

        String translatedClassVersion = "unknown";
        List<String> classFiles = FileUtils.getAllRelevantClassFiles(projectPath.toString());
        VersionIdentifier versionIdentifier = new VersionIdentifier();
        int classVersion = versionIdentifier.getNonConflictingVersionInformation(classFiles);
        if (classVersion > 0 && classVersion < 52) classVersion = 52;
        translatedClassVersion = versionIdentifier.translateVersion(classVersion);
        if (translatedClassVersion.equals("unknown")) translatedClassVersion = null;

        JessConfiguration config = new JessConfiguration(false, false, true,
                true, false, true, translatedClassVersion);

        Set<String> packages = PackageFinder.findPackageRoots(projectPath.toString());
        Jess jess = new Jess(config, packages, Collections.emptyList());
        jess.preSlice(targetClass, Collections.singletonList(methodSignature), Collections.emptyList(), Collections.emptyList());
        int jessResult = jess.parse(targetClass);

        BytecodeComparator comp = new BytecodeComparator(CompilerInvoker.output, projectPath.toString());
        String[] splitTargetClass = targetClass.replace("\\", "/").replace(".java", "").split("/");
        String targetClassName = splitTargetClass[splitTargetClass.length - 1];
        List<MethodComparison> comparisons = comp.compareMethods(targetClassName, false);
        comparisons.forEach(com -> {
            if (com.isEqual()) {
                System.out.println("equal");
                return;
            };
            System.out.println(com.getNormalizedLevenshteinDistance());
            System.out.println(com.getEquality());
            try {
                Path actualPath = Paths.get("tmp/actual.txt");
                Path expectedPath = Paths.get("tmp/expected.txt");
                Files.writeString(actualPath, com.getActualContent());
                Files.writeString(expectedPath, com.getExpectedContent());
                Runtime.getRuntime().exec("cmd /c start WinMergeU.exe " + actualPath.toAbsolutePath() + " " + expectedPath.toAbsolutePath());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
    }
}
