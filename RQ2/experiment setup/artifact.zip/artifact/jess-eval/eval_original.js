const fs = require('fs');
const spawnSync = require('child_process').spawnSync;

const reposFile = process.argv[2];
const jar = process.argv[3];

const repos = fs.readFileSync(reposFile, 'utf8').toString().trim();
const reposList = repos.split('\n').map(r => r.trim());

// args:
// <MAVEN_PATH>  <COMPILATION_AMOUNT>  <MINIMUM_LOC>  <CLEANUP_REPOS>  <RUN_MAVEN>  <BATCH_DIFF_MODE> <REPO_URL>

for (const repo of reposList) {
    const code = spawnSync('java', ['-jar', jar, '/usr/bin/mvn', '100', '3', 'true', 'true', 'false', repo], { stdio: 'inherit', timeout: 7200000 });
    spawnSync('mvn', ['dependency:purge-local-repository', '-DreResolve=false']);
    fs.rmSync('/root/.m2', { recursive: true, force: true });
    spawnSync('mvn', ['install', '-DskipTests'], { stdio: 'inherit', cwd: '/dependency-donwload-maven-plugin' });
    // const code = spawnSync('java', ['-jar', jar, '/usr/bin/mvn', '100', '3', 'false', 'false', 'false', repo], { stdio: 'inherit', timeout: 180000 });
}

// batch diff mode
// const code = spawnSync('java', ['-jar', jar, '/usr/bin/mvn', '100', '3', 'false', 'true', 'true'], { stdio: 'inherit', timeout: 7200000 });
