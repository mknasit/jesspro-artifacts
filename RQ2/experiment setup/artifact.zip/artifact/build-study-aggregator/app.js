const fs = require("fs");

const BUILD_STUDY = process.argv[3];
const JESS_STUDY = process.argv[4];

const compareResults = () => {
    const buildResultsJson = fs.readFileSync(BUILD_STUDY).toString().trim();
    const splitBuildResultsJson = buildResultsJson.split('\n');
    const buildResults = splitBuildResultsJson.map(res => JSON.parse(res.trim()));

    const jessResultsJson = fs.readFileSync(JESS_STUDY).toString().trim();
    const splitJessResultsJson = jessResultsJson.split('\n');
    const jessResults = splitJessResultsJson.map(res => JSON.parse(res.trim()));

    // compareSingleResults(buildResults, jessResults, "deps");
    const slicingResults = aggregateSingleResults(buildResults, jessResults, "slicing");
    const stubbingResults = aggregateSingleResults(buildResults, jessResults, "ambiguous stubbing");
    const depPluginResults = aggregateSingleResults(buildResults, jessResults, "deps");
    // uniqueResults(buildResults, jessResults, 'slicing');
    // uniqueResults(buildResults, jessResults, 'ambiguous stubbing');
    // uniqueResults(buildResults, jessResults, 'deps');

    const fullResults = { slicingResults, stubbingResults, depPluginResults };
    
    fs.writeFileSync(process.argv[5], JSON.stringify(fullResults, null, 2));
};

const aggregateSingleResults = (buildResults, jessResults, type) => {
    const singleResults = jessResults.filter(res => res.type === type);

    const cleanResults = {
        // totalStatement: 0,
        antFiles: 0,
        antFileSuccess: 0,
        antFullSuccess: 0,
        mavenFiles: 0,
        mavenFileSuccess: 0,
        mavenFullSuccess: 0,
        gradleFiles: 0,
        gradleFileSuccess: 0,
        gradleFullSuccess: 0,
        totalFixes: 0,
        totalFiles: 0,
        jessFileSuccess: 0,
        jessPartialSuccess: 0,
        // jessPartialStatementSuccess: 0,
        jessFullSuccess: 0,
        // commonFullSuccess: 0,
        // commonFileSuccess: 0
    };

    const aggregatedVulResults = { ...cleanResults };
    const aggregatedFixResults = { ...cleanResults };


    const alreadyConsideredCveId = [];
    singleResults.forEach(jessResult => {
        const matchingBuildResult = buildResults.find(buildResult => buildResult.cveId === jessResult.cveId && buildResult.fixId === jessResult.fixId);
        if (matchingBuildResult == null) return;
        if (matchingBuildResult.vulResult.buildTool === 'unknown' || matchingBuildResult.fixResult.buildTool === 'unknown') return;

        aggregatedVulResults.totalFixes++;
        aggregatedFixResults.totalFixes++;

        // check if cve id has already been included into the amount of unique statements
        if (!alreadyConsideredCveId.includes(jessResult.cveId)) {
            // if (jessResult.vulResult.buildSuccess > 0) aggregatedVulResults.jessPartialStatementSuccess++;
            // if (jessResult.fixResult.buildSuccess > 0) aggregatedFixResults.jessPartialStatementSuccess++;


            // aggregatedVulResults.totalStatement++;
            // aggregatedFixResults.totalStatement++;
            alreadyConsideredCveId.push(jessResult.cveId);
        }

        // vul aggregation
        aggregatedVulResults.totalFiles += jessResult.vulResult.totalFiles;
        aggregatedVulResults[`${matchingBuildResult.vulResult.buildTool}Files`] += jessResult.vulResult.totalFiles;
        aggregatedVulResults.jessFileSuccess += jessResult.vulResult.buildSuccess;
        if (jessResult.vulResult.buildSuccess > 0) aggregatedVulResults.jessPartialSuccess++;
        if (jessResult.vulResult.buildSuccess === jessResult.vulResult.totalFiles) aggregatedVulResults.jessFullSuccess++;
        if (jessResult.vulResult.buildSuccess === jessResult.vulResult.totalFiles && matchingBuildResult.vulResult.buildSuccess) {
            // aggregatedVulResults.commonFullSuccess++;
            // aggregatedVulResults.commonFileSuccess += jessResult.vulResult.buildSuccess;
        }
        if (matchingBuildResult.vulResult.buildSuccess) {
            aggregatedVulResults[`${matchingBuildResult.vulResult.buildTool}FileSuccess`] += jessResult.vulResult.buildSuccess;
            aggregatedVulResults[`${matchingBuildResult.vulResult.buildTool}FullSuccess`]++;
        }

        // fix aggregation
        aggregatedFixResults.totalFiles += jessResult.fixResult.totalFiles;
        aggregatedFixResults[`${matchingBuildResult.fixResult.buildTool}Files`] += jessResult.fixResult.totalFiles;
        aggregatedFixResults.jessFileSuccess += jessResult.fixResult.buildSuccess;
        if (jessResult.fixResult.buildSuccess > 0) aggregatedFixResults.jessPartialSuccess++;
        if (jessResult.fixResult.buildSuccess === jessResult.fixResult.totalFiles) aggregatedFixResults.jessFullSuccess++;
        if (jessResult.fixResult.buildSuccess === jessResult.fixResult.totalFiles && matchingBuildResult.fixResult.buildSuccess) {
            // aggregatedFixResults.commonFullSuccess++;
            // aggregatedFixResults.commonFileSuccess += jessResult.fixResult.buildSuccess;
        }
        if (matchingBuildResult.fixResult.buildSuccess) {
            aggregatedFixResults[`${matchingBuildResult.fixResult.buildTool}FileSuccess`] += jessResult.fixResult.buildSuccess;
            aggregatedFixResults[`${matchingBuildResult.fixResult.buildTool}FullSuccess`]++;
        }
 
    });
    // console.log('Type: ' + type);
    // console.log("Vul:");
    // console.log(aggregatedVulResults);
    // console.log("Fix:");
    // console.log(aggregatedFixResults);

    return aggregatedFixResults;
};

const uniqueResults = (buildResults, jessResults, type) => {
    const uniqueVulResults = {
        uJessFull: 0,
        uJessPartial: 0,
        antAll: 0,
        antPartial: 0,
        mavenAll: 0,
        mavenPartial: 0,
        gradleAll: 0,
        gradlePartial: 0,
    };

    const uniqueFixResults = {
        uJessFull: 0,
        uJessPartial: 0,
        antAll: 0,
        antPartial: 0,
        mavenAll: 0,
        mavenPartial: 0,
        gradleAll: 0,
        gradlePartial: 0,
    };


    const singleResults = jessResults.filter(res => res.type === type);

    singleResults.forEach(jessResult => {
        const matchingBuildResult = buildResults.find(buildResult => buildResult.cveId === jessResult.cveId && buildResult.fixId === jessResult.fixId);
        if (matchingBuildResult == null) return;

        if (!matchingBuildResult.fixResult.buildSuccess) {
            if (jessResult.fixResult.buildSuccess > 0) uniqueFixResults.uJessPartial++;
            if (jessResult.fixResult.buildSuccess === jessResult.fixResult.totalFiles) uniqueFixResults.uJessFull++;
        } else {
            if (jessResult.fixResult.buildSuccess === 0) uniqueFixResults[`${matchingBuildResult.fixResult.buildTool}All`]++;
            if (jessResult.fixResult.buildSuccess > 0 && jessResult.fixResult.buildSuccess < jessResult.fixResult.totalFiles) uniqueFixResults[`${matchingBuildResult.fixResult.buildTool}Partial`]++;
        }

        if (!matchingBuildResult.vulResult.buildSuccess) {
            if (jessResult.vulResult.buildSuccess > 0) uniqueVulResults.uJessPartial++;
            if (jessResult.vulResult.buildSuccess === jessResult.vulResult.totalFiles) uniqueVulResults.uJessFull++;
        } else {
            if (jessResult.vulResult.buildSuccess === 0) uniqueVulResults[`${matchingBuildResult.vulResult.buildTool}All`]++;
            if (jessResult.vulResult.buildSuccess > 0 && jessResult.vulResult.buildSuccess < jessResult.vulResult.totalFiles) uniqueVulResults[`${matchingBuildResult.vulResult.buildTool}Partial`]++;
        }
    });

    console.log("Vul Unique " + type + " :");
    console.log(uniqueVulResults);
    console.log("Fix Unique " + type + " :");
    console.log(uniqueFixResults);
};

const compareSingleResults = (buildResults, jessResults, type) => {
    const singleResults = jessResults.filter(res => res.type === type);

    const matchedResults = [];
    singleResults.forEach(res => {
        const matchingBuildResult = buildResults.find(bRes => bRes.cveId === res.cveId && bRes.fixId === res.fixId);
        if (matchingBuildResult == null) return;

        const matchedResult = {
            cveId: res.cveId,
            fixId: res.fixId,
            vulBuild: `${matchingBuildResult.vulResult.buildSuccess ? res.vulResult.totalFiles : 0}/${res.vulResult.totalFiles}`,
            vulJess: `${res.vulResult.buildSuccess}/${res.vulResult.totalFiles}`,
            fixBuild: `${matchingBuildResult.fixResult.buildSuccess ? res.fixResult.totalFiles : 0}/${res.fixResult.totalFiles}`,
            fixJess: `${res.fixResult.buildSuccess}/${res.fixResult.totalFiles}`,
        };
        matchedResults.push(matchedResult);
    });
    console.log(matchedResults);
};

const printBuildStudyResults = () => {
    const resultsJson = fs.readFileSync(BUILD_STUDY).toString().trim();
    const splitResultsJson = resultsJson.split('\n');
    const results = splitResultsJson.map(res => JSON.parse(res.trim()));
    const compilable = results.filter(res => res.fixResult.compilable);
    const vulCompileSuccess = compilable.filter(res => res.vulResult.buildSuccess);
    const fixCompileSuccess = compilable.filter(res => res.fixResult.buildSuccess);
    const fullCompileSuccess = compilable.filter(res => res.fixResult.buildSuccess && res.vulResult.buildSuccess);
    const mavenProjects = compilable.filter(res => res.fixResult.buildTool === "maven");
    const gradleProjects = compilable.filter(res => res.fixResult.buildTool === "gradle");
    const antProjects = compilable.filter(res => res.fixResult.buildTool === "ant");

    const mavenFixSuccess = mavenProjects.filter(res => res.fixResult.buildSuccess);
    const gradleFixSuccess = gradleProjects.filter(res => res.fixResult.buildSuccess);
    const antFixSuccess = antProjects.filter(res => res.fixResult.buildSuccess);

    const mavenSuccess = mavenProjects.filter(res => res.fixResult.buildSuccess && res.vulResult.buildSuccess);
    const gradleSuccess = gradleProjects.filter(res => res.fixResult.buildSuccess && res.vulResult.buildSuccess);
    const antSuccess = antProjects.filter(res => res.fixResult.buildSuccess && res.vulResult.buildSuccess);

    const finalResults = {
        antTheoreticallyCompilableFixes: antProjects.length,
        antCompilationSuccessFixes: antFixSuccess.length,
        antFiles: antProjects.reduce((acc, entry) =>  acc += entry.fixResult.totalFiles, 0),
        antCompiledFiles: antFixSuccess.reduce((acc, entry) =>  acc += entry.fixResult.totalFiles, 0),
        mavenTheoreticallyCompilableFixes: mavenProjects.length,
        mavenCompilationSuccessFixes: mavenFixSuccess.length,
        mavenFiles: mavenProjects.reduce((acc, entry) =>  acc += entry.fixResult.totalFiles, 0),
        mavenCompiledFiles: mavenFixSuccess.reduce((acc, entry) =>  acc += entry.fixResult.totalFiles, 0),
        gradleTheoreticallyCompilableFixes: gradleProjects.length,
        gradleCompilationSuccessFixes: gradleFixSuccess.length,
        gradleFiles: gradleProjects.reduce((acc, entry) =>  acc += entry.fixResult.totalFiles, 0),
        gradleCompiledFiles: gradleFixSuccess.reduce((acc, entry) =>  acc += entry.fixResult.totalFiles, 0),
        totalTheoreticallyCompilableFixes: compilable.length,
        totalCompilationSuccessFixes: fixCompileSuccess.length,
        totalFiles: compilable.reduce((acc, entry) =>  acc += entry.fixResult.totalFiles, 0),
        totalCompiledFiles: fixCompileSuccess.reduce((acc, entry) =>  acc += entry.fixResult.totalFiles, 0),
    }

    // console.log("Total fixes:", results.length);
    // console.log("Total compilable:", compilable.length);
    // console.log("Total vul compilation success:", vulCompileSuccess.length);
    // console.log("Total fix compilation success:", fixCompileSuccess.length);
    
    // console.log("Maven projects fix:", mavenFixSuccess.length, "/", mavenProjects.length);
    // console.log("Gradle projects fix:", gradleFixSuccess.length, "/", gradleProjects.length);
    // console.log("Ant projects fix:", antFixSuccess.length, "/", antProjects.length);

    // console.log("Total full compilation success:", fullCompileSuccess.length);

    fs.writeFileSync(process.argv[4], JSON.stringify(finalResults, null, 2));
};

if (process.argv[2] == "default") {
    printBuildStudyResults();
} 

if (process.argv[2] == "jess") {
    compareResults();
}