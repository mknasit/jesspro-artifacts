# Running RQ1 & RQ2 Intersection Experiment

This guide explains how to run the `rq1_rq2_intersection.sh` script for the RQ1 and RQ2 intersection experiment.

## Prerequisites

### 1. Clone Jess Repository

Before running the experiment, you need to clone the Jess repository into the artifact directory:

```bash
cd RQ2/experiment setup/artifact/
git clone https://github.com/stschott/jess.git jess/
```

**Important**: The `jess` directory must be located at `RQ2/experiment setup/artifact/jess/`

### 2. Build Required Components

Before running the main script, you need to build three components using Maven. Run these commands in order:

```bash
# 1. Build dependency-download-maven-plugin
cd dependency-download-maven-plugin
mvn -q -DskipTests install
cd ..

# 2. Build jess
cd jess
mvn -q -DskipTests clean package
cd ..

# 3. Build jess-eval
cd jess-eval
mvn -q -DskipTests install
cd ..
```

**Note**: The `-q` flag runs Maven in quiet mode, and `-DskipTests` skips running tests to speed up the build process.

## Running the Experiment

### Step 1: Ensure Docker is Running

Make sure Docker is installed and running on your system. The script uses a Docker container named `jess-study`.

### Step 2: Check Required Files

The script expects an intersection file at:
```
jess-eval/input/eval_repos_intersection_old.txt
```

Make sure this file exists before running the script.

### Step 3: Run the Script

From the artifact directory, make the script executable (if needed) and run it:

```bash
chmod +x rq1_rq2_intersection.sh
./rq1_rq2_intersection.sh
```

## What the Script Does

1. **Validates Input**: Checks for the required intersection file
2. **Runs Docker Container**: Executes the `jess-study` Docker container with:
   - Maven repository isolation (per-run temporary directories)
   - Mounted logs directory
   - Mounted intersection file as input
3. **Aggregates Results**: Uses the `jess-eval-aggregator` Node.js script to process results
4. **Generates Logs**: Creates several output files:
   - `run_logs-<timestamp>.txt`: Full console output
   - `failure_logs-<timestamp>.txt`: Filtered failure messages
   - `failures-structured-<timestamp>.tsv`: Structured failure data (if available)
   - Results in `logs/` directory:
     - `rq1_rq2_results.json`: Aggregated results
     - `single-builds.json`: Individual build results
     - `builds.json`: Build information (if generated)

## Output Files

After the script completes, you'll find:

- **Console Log**: `run_logs-<timestamp>.txt` - Complete console output
- **Failure Log**: `failure_logs-<timestamp>.txt` - Extracted failure messages
- **Structured Failures**: `failures-structured-<timestamp>.tsv` - Tab-separated failure data
- **Results**: 
  - `logs/rq1_rq2_results.json` - Main aggregated results
  - `logs/single-builds.json` - Individual build results

## Troubleshooting

- **"Intersection file not found"**: Ensure `jess-eval/input/eval_repos_intersection_old.txt` exists
- **Docker errors**: Make sure Docker is running and the `jess-study` image is built
- **Maven build failures**: Check that all three Maven builds completed successfully before running the script
- **Permission errors**: Make sure the script has execute permissions (`chmod +x rq1_rq2_intersection.sh`)

## Quick Start Summary

```bash
# 1. Clone jess
cd RQ2/experiment setup/artifact/
git clone https://github.com/stschott/jess.git jess/

# 2. Build components
(cd dependency-download-maven-plugin && mvn -q -DskipTests install)
(cd jess && mvn -q -DskipTests clean package)
(cd jess-eval && mvn -q -DskipTests install)

# 3. Run the experiment
./rq1_rq2_intersection.sh
```
