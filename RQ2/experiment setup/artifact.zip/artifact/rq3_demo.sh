#rm -f logs/rq3_results.json
#rm -f logs/kb-build.json 
#rm -f logs/kb-jess-build.json
#rm -f logs/kb-default-study.json
#stopIndex=8
#sudo docker run --rm --init -e stopIndex=$stopIndex --name kb-default-build --mount type=bind,source=/data/mknasit/jess-icse/work/artifact/logs,target=/build-study/logs kb-default-build
node build-study-aggregator/app default logs/kb-build.json logs/kb-default-study.json
#sudo docker run --rm --init -e stopIndex=$stopIndex --name kb-jess-build --mount type=bind,source=/data/mknasit/jess-icse/work/artifact/logs,target=/kb-compiler/logs kb-jess-build
#node build-study-aggregator/app jess logs/kb-build.json logs/kb-jess-build.json logs/rq3_results.json
open logs/rq3_results.json logs/kb-default-study.json
