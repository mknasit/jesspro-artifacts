package de.upb.sse.buildstudy.model;

import java.util.Set;

public class BuildInfo {
    private final String buildTool;
    private final Set<String> gradleDirs;
    private final Set<String> mavenDirs;
    private final Set<String> antDirs;

    public BuildInfo(Set<String> gradleDirs, Set<String> mavenDirs, Set<String> antDirs) {
        this.gradleDirs = gradleDirs;
        this.mavenDirs = mavenDirs;
        this.antDirs = antDirs;

        if (!gradleDirs.isEmpty()) buildTool = "gradle";
        else if (!mavenDirs.isEmpty()) buildTool = "maven";
        else if (!antDirs.isEmpty()) buildTool = "ant";
        else buildTool = "unknown";
    }

    public String getBuildTool() {
        return buildTool;
    }

    public Set<String> getGradleDirs() {
        return gradleDirs;
    }

    public Set<String> getMavenDirs() {
        return mavenDirs;
    }

    public Set<String> getAntDirs() {
        return antDirs;
    }

    @Override
    public String toString() {
        return "BuildInfo{" +
                "buildTool='" + buildTool + '\'' +
                ", gradleDirs=" + gradleDirs +
                ", mavenDirs=" + mavenDirs +
                ", antDirs=" + antDirs +
                '}';
    }
}
