package de.upb.sse.buildstudy;

import de.upb.sse.buildstudy.model.BuildInfo;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BuildFileFinder {

    public static BuildInfo getBuildDirs(List<String> filesToBuild) {
        Set<String> gradleDirs = new HashSet<>();
        Set<String> mavenDirs = new HashSet<>();
        Set<String> antDirs = new HashSet<>();
        for (String fileToBuild : filesToBuild) {
            String gradlewBatFile = findOutermostDirectoryContaining(fileToBuild, "gradlew.bat");
            if (gradlewBatFile != null) gradleDirs.add(gradlewBatFile);

            String gradleBuildFile = findOutermostDirectoryContaining(fileToBuild, "build.gradle");
            if (gradleBuildFile != null) gradleDirs.add(gradleBuildFile);

            String gradleBuildKtFile = findOutermostDirectoryContaining(fileToBuild, "build.gradle.kt");
            if (gradleBuildKtFile != null) gradleDirs.add(gradleBuildKtFile);

            String pomFile = findOutermostDirectoryContaining(fileToBuild, "pom.xml");
            if (pomFile != null) mavenDirs.add(pomFile);

            String antBuildFile = findOutermostDirectoryContaining(fileToBuild, "build.xml");
            if (antBuildFile != null) antDirs.add(antBuildFile);
        }

        return new BuildInfo(gradleDirs, mavenDirs, antDirs);
    }

    public static String findOutermostDirectoryContaining(String filePath, String fileToFind) {
        String outermostFile = null;
        File file = new File(filePath);

        while (file != null) {
            if (!file.exists()) return null;

            if (file.isFile()) {
                file = file.getParentFile();
            } else {
                File searchedFile = new File(file + File.separator + fileToFind);
                if (searchedFile.exists() && (outermostFile == null || searchedFile.getAbsolutePath().length() < outermostFile.length())) {
                    outermostFile = file.getAbsolutePath();
                }
                file = file.getParentFile();
            }
        }

        return outermostFile;
    }
}
