package de.upb.sse.buildstudy.model;

public class BuildResult {
    private final String cveId;
    private final String fixId;

    private final SingleBuildResult vulResult;
    private final SingleBuildResult fixResult;

    public BuildResult(String cveId, String fixId, SingleBuildResult vulResult, SingleBuildResult fixResult) {
        this.cveId = cveId;
        this.fixId = fixId;
        this.vulResult = vulResult;
        this.fixResult = fixResult;
    }

    public String getCveId() {
        return cveId;
    }

    public String getFixId() {
        return fixId;
    }

    public SingleBuildResult getVulResult() {
        return vulResult;
    }

    public SingleBuildResult getFixResult() {
        return fixResult;
    }

    @Override
    public String toString() {
        return "BuildResult{" +
                "cveId='" + cveId + '\'' +
                ", fixId='" + fixId + '\'' +
                ", vulResult=" + vulResult +
                ", fixResult=" + fixResult +
                '}';
    }
}
