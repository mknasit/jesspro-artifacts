package de.upb.sse.buildstudy;

import de.upb.sse.buildstudy.model.BuildInfo;

import java.io.File;
import java.nio.file.Path;
import java.util.List;
import java.util.Scanner;

public class BuildInvoker {

    public static boolean runBuild(BuildInfo buildInfo) {
        if (buildInfo.getBuildTool().equals("gradle")) {
            for (String buildDir : buildInfo.getGradleDirs()) {
                boolean buildResult = buildGradle(buildDir);
                if (!buildResult) return false;
            }
            return true;
        } else if (buildInfo.getBuildTool().equals("maven")) {
            for (String buildDir : buildInfo.getMavenDirs()) {
                boolean buildResult = buildMaven(buildDir);
                if (!buildResult) return false;
            }
            return true;
        } else if (buildInfo.getBuildTool().equals("ant")) {
            for (String buildDir : buildInfo.getAntDirs()) {
                boolean buildResult = buildAnt(buildDir);
                if (!buildResult) return false;
            }
            return true;
        }

        return false;
    }

    public static boolean buildGradle(String workingDir) {
        boolean wrapperSuccess;
        if (System.getProperty("os.name").startsWith("Windows")) {
            wrapperSuccess = runCommand(List.of("gradlew.bat"), workingDir);
        } else {
            wrapperSuccess = runCommand(List.of("./gradlew"), workingDir);
        }
        if (wrapperSuccess) return true;

        return runCommand(List.of(Path.of(Main.GRADLE_PATH).toString(),  "build"), workingDir);
    }

    public static boolean buildMaven(String workingDir) {
        return runCommand(List.of(Path.of(Main.MAVEN_PATH).toString(), "compile"), workingDir);
    }

    public static boolean buildAnt(String workingDir) {
        boolean buildSuccess = runCommand(List.of(Path.of(Main.ANT_PATH).toString(), "build"), workingDir);
        if (buildSuccess) return true;
        return runCommand(List.of(Path.of(Main.ANT_PATH).toString(), "compile"), workingDir);
    }

    public static boolean runCommand(List<String> command, String workingDir) {
        try {
            ProcessBuilder builder = new ProcessBuilder(command);
            builder.directory( new File(workingDir) );
            builder.redirectErrorStream(true);
            Process process = builder.start();

            Scanner s = new Scanner(process.getInputStream());
            StringBuilder text = new StringBuilder();
            while (s.hasNextLine()) {
                text.append(s.nextLine());
                text.append("\n");
            }
            s.close();

            int result = process.waitFor();
            System.out.printf( "Process exited with result %d and output %s%n", result, text );
            return result == 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }

}
