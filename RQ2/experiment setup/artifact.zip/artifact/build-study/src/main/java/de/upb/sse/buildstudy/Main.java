package de.upb.sse.buildstudy;

import com.google.gson.Gson;
import de.upb.sse.buildstudy.model.BuildInfo;
import de.upb.sse.buildstudy.model.BuildResult;
import de.upb.sse.buildstudy.model.SingleBuildResult;
import de.upb.sse.srcdiffer.Differ;
import de.upb.sse.srcdiffer.model.diff.ClassDiff;
import de.upb.sse.srcdiffer.model.diff.CveDiff;
import de.upb.sse.srcdiffer.model.diff.DiffType;
import de.upb.sse.srcdiffer.model.diff.FixDiff;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static String KB_PATH;
    public static String GRADLE_PATH;
    public static String MAVEN_PATH;
    public static String ANT_PATH;
    public static String OUTPUT = "repos";
    public static int INDEX;
    private final static Differ differ = new Differ(OUTPUT);
    private final static Logger logger = new Logger(new File("logs/kb-build.json"));

    private static List<BuildResult> buildResults = new ArrayList<>();

    public static void main(String[] args) {
        KB_PATH = args.length > 0 ? args[0] : "C:/Users/Stefan/Desktop/Hektor/project-kb/statements";
        GRADLE_PATH = args.length > 1 ? args[1] : "C:/Program Files/Java/gradle-7.4/bin/gradle.bat";
        MAVEN_PATH = args.length > 2 ? args[2] : "C:/Program Files/Java/apache-maven-3.8.4/bin/mvn.cmd";
        ANT_PATH = args.length > 3 ? args[3] : "C:/Program Files/Java/apache-ant-1.10.12/bin/ant.bat";
        INDEX = Integer.parseInt(args[4]);
        List<String> statements = getStmts();

        if (statements.size() <= INDEX) return;

        String stmt = statements.get(INDEX);
        processStmt(stmt);

        try {
            org.apache.commons.io.FileUtils.deleteDirectory(new File(OUTPUT));
        } catch (IOException e) {
            System.out.println("Failed to delete output directory");
        }

    }

    public static void processFixDiff(String cveId, FixDiff fixDiff) {
        List<String> oldFilePaths = new ArrayList<>();
        List<String> newFilePaths = new ArrayList<>();

        int totalFiles = 0;
        for (ClassDiff classDiff : fixDiff.getChangedClasses()) {
            if (!hasChangesToCompile(classDiff)) continue;
            if (classDiff.getDiffType().equals(DiffType.REMOVED)) continue;
            if (classDiff.getDiffType().equals(DiffType.ADDED)) continue;

            oldFilePaths.add(classDiff.getOldClassPath());
            newFilePaths.add(classDiff.getNewClassPath());
            totalFiles++;
        }

        oldFilePaths = oldFilePaths.stream().map(p -> fixDiff.getOutputPath() + File.separator + p).collect(Collectors.toList());
        newFilePaths = newFilePaths.stream().map(p -> fixDiff.getOutputPath() + File.separator + p).collect(Collectors.toList());


        try {
            Util.checkoutVulVersion(fixDiff.getOutputPath(), fixDiff.getFirstCommitId());
            BuildInfo vulBuild = BuildFileFinder.getBuildDirs(oldFilePaths);
            SingleBuildResult vulBuildResult;
            if (!vulBuild.getBuildTool().equals("unknown")) {
                vulBuildResult = new SingleBuildResult(true, vulBuild.getBuildTool(), BuildInvoker.runBuild(vulBuild), totalFiles);
            } else {
                vulBuildResult = new SingleBuildResult(false, totalFiles);
            }

            Util.checkoutFixVersion(fixDiff.getOutputPath(), fixDiff.getLastCommitId());
            BuildInfo fixBuild = BuildFileFinder.getBuildDirs(newFilePaths);
            SingleBuildResult fixBuildResult;
            if (!fixBuild.getBuildTool().equals("unknown")) {
                fixBuildResult = new SingleBuildResult(true, fixBuild.getBuildTool(), BuildInvoker.runBuild(fixBuild), totalFiles);
            } else {
                fixBuildResult = new SingleBuildResult(false, totalFiles);
            }

            BuildResult buildResult = new BuildResult(cveId, fixDiff.getId(), vulBuildResult, fixBuildResult);
            buildResults.add(buildResult);
            System.out.println(buildResult);
            System.out.println("-------------------------------------------");

            Gson gson = new Gson();
            String json = gson.toJson(buildResult);
            logger.log(json);

        }  catch (Throwable e) {
            e.printStackTrace();
        }
    }

    public static void processCveDiff(CveDiff diff) {
        System.out.println("Current Statement: " + diff.getId());
        if (!hasChangesToCompile(diff)) return;

        for (FixDiff fixDiff : diff.getFixDiffs()) {
            if (!hasChangesToCompile(fixDiff)) continue;

            System.out.println("Current Fix: " + fixDiff.getId());
            processFixDiff(diff.getId(), fixDiff);
        }

    }

    public static void processStmt(String stmt) {
        Map<String, CveDiff> cveDiffs = differ.diffStatement(stmt);
        Map<String, CveDiff> sortedDiffs = sort(cveDiffs);

        for (Map.Entry<String, CveDiff> entry : sortedDiffs.entrySet()) {
            processCveDiff(entry.getValue());
        }
    }

    public static Map<String, CveDiff> sort(Map<String, CveDiff> diffs) {
        return diffs.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.comparing(CveDiff::getId)))
                .collect(Collectors.toMap(
                        Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new)
                );
    }

    public static List<String> getStmts() {
        File[] statementDirs = new File(KB_PATH).listFiles(File::isDirectory);
        Arrays.sort(statementDirs);
        return Arrays.stream(statementDirs)
                .map(sd -> Paths.get(sd.getAbsolutePath()).toFile())
                .filter(File::exists)
                .map(File::getAbsolutePath)
                .collect(Collectors.toList());
    }

    public static boolean hasChangesToCompile(CveDiff diff) {
        return diff.getFixDiffs().stream().anyMatch(Main::hasChangesToCompile);
    }

    public static boolean hasChangesToCompile(FixDiff diff) {
        return diff.getChangedClasses().stream().anyMatch(Main::hasChangesToCompile);
    }

    public static boolean hasChangesToCompile(ClassDiff diff) {
        List<String> vulMethodsToKeep = new ArrayList<>(diff.getChangedMethods());
        vulMethodsToKeep.addAll(diff.getRemovedMethods());

        List<String> fixMethodsToKeep = new ArrayList<>(diff.getChangedMethods());
        fixMethodsToKeep.addAll(diff.getAddedMethods());

        List<String> initChanges = diff.getInitChanges();
        List<String> clinitChanges = diff.getClinitChanges();

        return !vulMethodsToKeep.isEmpty() ||
                !fixMethodsToKeep.isEmpty() ||
                !initChanges.isEmpty() ||
                !clinitChanges.isEmpty();
    }
}
