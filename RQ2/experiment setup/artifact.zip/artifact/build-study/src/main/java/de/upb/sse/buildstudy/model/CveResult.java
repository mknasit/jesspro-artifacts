package de.upb.sse.buildstudy.model;

import java.util.ArrayList;
import java.util.List;

public class CveResult {
    public String cveId;
    public boolean fixSuccess = false;
    public boolean vulSuccess = false;
    public boolean partialFixSuccess = false;
    public boolean partialVulSuccess = false;

    public CveResult(String cveId) {
        this.cveId = cveId;
    }

    @Override
    public String toString() {
        return "CveResult{" +
                "cveId='" + cveId + '\'' +
                ", fixSuccess=" + fixSuccess +
                ", vulSuccess=" + vulSuccess +
                ", partialFixSuccess=" + partialFixSuccess +
                ", partialVulSuccess=" + partialVulSuccess +
                '}';
    }
}
