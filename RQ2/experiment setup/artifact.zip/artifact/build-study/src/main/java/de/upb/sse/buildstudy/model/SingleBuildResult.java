package de.upb.sse.buildstudy.model;

public class SingleBuildResult {
    private final boolean compilable;
    private final String buildTool;
    private final boolean buildSuccess;

    private final int totalFiles;

    public SingleBuildResult(boolean compilable, int totalFiles) {
        this(false, "unknown", false, totalFiles);
    }

    public SingleBuildResult(boolean compilable, String buildTool, boolean buildSuccess, int totalFiles) {
        this.compilable = compilable;
        this.buildTool = buildTool;
        this.buildSuccess = buildSuccess;
        this.totalFiles = totalFiles;
    }

    public boolean isCompilable() {
        return compilable;
    }

    public String getBuildTool() {
        return buildTool;
    }

    public boolean isBuildSuccess() {
        return buildSuccess;
    }

    public int getTotalFiles() {
        return totalFiles;
    }

    @Override
    public String toString() {
        return "SingleBuildResult{" +
                "compilable=" + compilable +
                ", buildTool='" + buildTool + '\'' +
                ", buildSuccess=" + buildSuccess +
                ", totalFiles=" + totalFiles +
                '}';
    }
}
