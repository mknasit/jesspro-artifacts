package de.upb.sse.buildstudy;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.lib.ObjectId;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class Util {

    public static Set<String> findFilePaths(String rootDir, String fileName) {
        final Set<String> files;
        Set<String> filesTemp;
        try {
            filesTemp = Files.find(Paths.get(rootDir), 999,
                            (p, bfa) -> bfa.isRegularFile() && p.getFileName().toString().equals(fileName)
                    ).map(p -> p.getParent().toString())
                    .collect(Collectors.toSet());
        } catch (IOException e) {
            e.printStackTrace();
            filesTemp = new HashSet<>();
        }
        files = filesTemp;

        Set<String> topLevelFiles = new HashSet<>();
        for (String file : files) {
//            if (pomFiles.stream().anyMatch(p -> !p.equals(pomFile) && pomFile.startsWith(p))) continue;
            topLevelFiles.add(file);
        }

        return topLevelFiles;
    }

    public static void checkoutVulVersion(String repoPath, String commitId) throws IOException {
        try (Git git = Git.open(new File(repoPath))) {
            ObjectId previousCommitId = git.getRepository().resolve( commitId + "^" );
            git.checkout().setName(previousCommitId.getName()).call();
        } catch (GitAPIException e) {
            e.printStackTrace();
        }

    }

    public static void checkoutFixVersion(String repoPath, String commitId) throws IOException {
        try (Git git = Git.open(new File(repoPath))) {
            git.checkout().setName(commitId).call();
        } catch (GitAPIException e) {
            e.printStackTrace();
        }
    }
}
