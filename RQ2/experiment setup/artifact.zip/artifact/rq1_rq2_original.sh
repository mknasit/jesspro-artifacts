rm -f logs/rq1_rq2_results.json
rm -f logs/single-builds.json
repos=input/eval_repos.txt
sudo docker run --rm --init -e repos=$repos --name jess-study --mount type=bind,source=/data/mknasit/jess-icse/work/artifact/logs,target=/jess-eval/logs jess-study
node jess-eval-aggregator/app logs/single-builds.json logs/rq1_rq2_results.json
open logs/rq1_rq2_results.json
