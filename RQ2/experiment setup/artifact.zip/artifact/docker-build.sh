sudo docker build --tag jess-study -f docker/jess-study/Dockerfile .
sudo docker build --tag kb-default-build -f docker/kb-default-build/Dockerfile .
sudo docker build --tag kb-jess-build -f docker/kb-jess-build/Dockerfile .
