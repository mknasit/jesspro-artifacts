rm -f logs/rq1_rq2_results.json
rm -f logs/single-builds.json
RUN_TAG=$(date +%Y%m%d_%H%M%S)
MAVEN_REPO="/tmp/mvnrepo_${RUN_TAG}"
MAVEN_TMP="/tmp/mvntmp_${RUN_TAG}"
repos=input/eval_repos.txt
# sudo docker run --rm --init -e repos=$repos --name jess-study --mount type=bind,source=/data/mknasit/jess-icse/work/artifact/logs,target=/jess-eval/logs jess-study
sudo docker run --rm --init \
  -e repos="$repos" \
  -e MAVEN_OPTS="-Dmaven.repo.local=$MAVEN_REPO -Djava.io.tmpdir=$MAVEN_TMP -Dmaven.wagon.http.retryHandler.count=3" \
  --name jess-study \
  --mount type=bind,source=/data/mknasit/jess-icse/work/artifact/logs,target=/jess-eval/logs \
  jess-study

node jess-eval-aggregator/app logs/single-builds.json logs/rq1_rq2_results.json
open logs/rq1_rq2_results.json
