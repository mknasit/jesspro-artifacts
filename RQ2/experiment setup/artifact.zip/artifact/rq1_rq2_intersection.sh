#!/usr/bin/env bash
set -euo pipefail

# --- HOST paths ---
ARTIFACT_ROOT="/data/mknasit/jess-icse/work/artifact"
LOGS_DIR="$ARTIFACT_ROOT/logs"
HOST_INTERSECTION="$ARTIFACT_ROOT/jess-eval/input/eval_repos_intersection_old.txt"

# --- Pre-flight ---
if [ ! -f "$HOST_INTERSECTION" ]; then
  echo "ERROR: Intersection file not found: $HOST_INTERSECTION" >&2
  exit 1
fi

echo "[INFO] Using intersection file: $HOST_INTERSECTION"
wc -l "$HOST_INTERSECTION" || true
head -n 3 "$HOST_INTERSECTION" || true

# Optional: clear previous summary jsons
rm -f "$LOGS_DIR/rq1_rq2_results.json" "$LOGS_DIR/single-builds.json" "$LOGS_DIR/builds.json"

# Per-run Maven repo (inside container)
RUN_TAG=$(date +%Y%m%d_%H%M%S)
MAVEN_REPO="/tmp/mvnrepo_${RUN_TAG}"
MAVEN_TMP="/tmp/mvntmp_${RUN_TAG}"

# Text logs in artifact root (what you asked)
TS=$(date +%Y-%m-%d_%H-%M-%S)
CONSOLE_LOG="$ARTIFACT_ROOT/run_logs-$TS.txt"
FAIL_TXT="$ARTIFACT_ROOT/failure_logs-$TS.txt"
FAIL_TSV="$ARTIFACT_ROOT/failures-structured-$TS.tsv"

echo "[INFO] Console will be captured to: $CONSOLE_LOG"
echo "[INFO] Failures will be written to: $FAIL_TXT"
echo "[INFO] Structured failures (if possible): $FAIL_TSV"

set -o pipefail
{
  echo "[INFO] Start: $(date -Is)"
  echo "[INFO] Maven repo inside container: $MAVEN_REPO"
  echo "[INFO] Temp inside container:      $MAVEN_TMP"

  # Force the container to read the intersection by overlaying the expected path
  sudo docker run --rm --init \
    -e repos="/jess-eval/input/eval_repos.txt" \
    -e MAVEN_OPTS="-Dmaven.repo.local=$MAVEN_REPO -Djava.io.tmpdir=$MAVEN_TMP -Dmaven.wagon.http.retryHandler.count=3" \
    --name jess-study \
    --mount type=bind,source="$LOGS_DIR",target=/jess-eval/logs \
    --mount type=bind,source="$HOST_INTERSECTION",target=/jess-eval/input/eval_repos.txt,readonly \
    jess-study

  echo "[INFO] Finished container: $(date -Is)"

  # Aggregate results into logs/ as usual
  node jess-eval-aggregator/app "$LOGS_DIR/single-builds.json" "$LOGS_DIR/rq1_rq2_results.json" || true
} 2>&1 | tee "$CONSOLE_LOG"

# Failures-only (grep) from console
grep -Ei '(^|[^a-z])fail(ed)?([^a-z]|$)|error|exception|timeout|timed out|not.*maven|no.*pom\.xml' \
  "$CONSOLE_LOG" > "$FAIL_TXT" || true

# Structured failures from builds.json (only if it contains JSON objects per line)
if [ -s "$LOGS_DIR/builds.json" ]; then
  jq -Rr '
    fromjson? | select(type=="object") |
    {p:(.projectName // .repo // .repo_url // "unknown"),
     s:(.status // .result // "unknown"),
     r:(.skipReason // .error // .message // "")} |
    select((.s|test("fail|error|timeout|skipp";"i")) or (.r|test("fail|error|timeout|not.*maven|no.*pom\\.xml";"i"))) |
    "\(.p)\t\(.s)\t\(.r)"
  ' "$LOGS_DIR/builds.json" > "$FAIL_TSV" || true
fi

echo "[INFO] Wrote console:   $CONSOLE_LOG"
echo "[INFO] Wrote failures:  $FAIL_TXT"
[ -s "$FAIL_TSV" ] && echo "[INFO] Wrote TSV:        $FAIL_TSV"
echo "[INFO] rq1_rq2_results:  $LOGS_DIR/rq1_rq2_results.json"
echo "[INFO] single-builds:    $LOGS_DIR/single-builds.json"
echo "[INFO] builds (if any):  $LOGS_DIR/builds.json"
