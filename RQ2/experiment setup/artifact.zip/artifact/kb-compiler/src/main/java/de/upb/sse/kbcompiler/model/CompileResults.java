package de.upb.sse.kbcompiler.model;

public class CompileResults {
    public boolean vulSlicingSuccess = false;
    public boolean vulStubbingSuccess = false;
    public boolean vulAStubbingSuccess = false;
    public boolean vulDepsSuccess = false;
    public boolean fixSlicingSuccess = false;
    public boolean fixStubbingSuccess = false;
    public boolean fixAStubbingSuccess = false;
    public boolean fixDepsSuccess = false;
    public boolean missingCommit = false;
    public boolean exception = false;

    public CompileResults() {
    }

    public CompileResults(boolean missingCommit, boolean exception) {
        this.missingCommit = missingCommit;
        this.exception = exception;
    }

    public CompileResults(boolean vulSlicingSuccess, boolean vulStubbingSuccess, boolean vulAStubbingSuccess, boolean vulDepsSuccess,
                          boolean fixSlicingSuccess, boolean fixStubbingSuccess, boolean fixAStubbingSuccess, boolean fixDepsSuccess) {
        this.vulSlicingSuccess = vulSlicingSuccess;
        this.vulStubbingSuccess = vulStubbingSuccess;
        this.vulAStubbingSuccess = vulAStubbingSuccess;
        this.vulDepsSuccess = vulDepsSuccess;
        this.fixSlicingSuccess = fixSlicingSuccess;
        this.fixStubbingSuccess = fixStubbingSuccess;
        this.fixAStubbingSuccess = fixAStubbingSuccess;
        this.fixDepsSuccess = fixDepsSuccess;
    }

    @Override
    public String toString() {
        return "CompileResults{" +
                "vulSlicingSuccess=" + vulSlicingSuccess +
                ", vulStubbingSuccess=" + vulStubbingSuccess +
                ", vulAStubbingSuccess=" + vulAStubbingSuccess +
                ", vulDepsSuccess=" + vulDepsSuccess +
                ", fixSlicingSuccess=" + fixSlicingSuccess +
                ", fixStubbingSuccess=" + fixStubbingSuccess +
                ", fixAStubbingSuccess=" + fixAStubbingSuccess +
                ", fixDepsSuccess=" + fixDepsSuccess +
                '}';
    }
}
