package de.upb.sse.kbcompiler.model;

public class CompileResult {
    public final boolean vul;
    public final boolean fix;
    public final boolean missingCommit;
    public final boolean ambiguous;
    public final boolean exception;

    public CompileResult(boolean vul, boolean fix) {
        this(vul, fix, false, false, false);
    }

    public CompileResult(boolean vul, boolean fix, boolean missingCommit, boolean ambiguous, boolean exception) {
        this.vul = vul;
        this.fix = fix;
        this.missingCommit = missingCommit;
        this.ambiguous = ambiguous;
        this.exception = exception;
    }
}
