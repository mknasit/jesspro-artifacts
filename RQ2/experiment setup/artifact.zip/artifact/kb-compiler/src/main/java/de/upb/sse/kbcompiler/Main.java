package de.upb.sse.kbcompiler;

import com.google.gson.Gson;
import de.upb.sse.jess.Jess;
import de.upb.sse.jess.configuration.JessConfiguration;
import de.upb.sse.jess.dependency.MavenDependencyResolver;
import de.upb.sse.jess.exceptions.AmbiguityException;
import de.upb.sse.jess.finder.JarFinder;
import de.upb.sse.jess.finder.PackageFinder;
import de.upb.sse.jess.finder.PomFinder;
import de.upb.sse.kbcompiler.model.AllStats;
import de.upb.sse.kbcompiler.model.CompileResults;
import de.upb.sse.kbcompiler.model.build.BuildResult;
import de.upb.sse.kbcompiler.model.build.CombinedResults;
import de.upb.sse.srcdiffer.Differ;
import de.upb.sse.srcdiffer.model.diff.ClassDiff;
import de.upb.sse.srcdiffer.model.diff.CveDiff;
import de.upb.sse.srcdiffer.model.diff.DiffType;
import de.upb.sse.srcdiffer.model.diff.FixDiff;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.errors.MissingObjectException;
import org.eclipse.jgit.lib.ObjectId;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static String KB_PATH;
    public static int INDEX;

    public final static String OUTPUT = "repos";
    public final static AllStats stats = new AllStats();
    private final static Differ differ = new Differ(OUTPUT);
    private final static Logger logger = new Logger(new File("logs/kb-jess-build.json"));

    private static List<BuildResult> buildResults = new ArrayList<>();

    public static void main(String[] args) {
        KB_PATH = args.length > 0 ? args[0] : "C:/Users/Stefan/Desktop/Hektor/project-kb/statements";
        INDEX = Integer.parseInt(args[1]);


//        List<String> stmts = getStmts().subList(SLICE_FROM, SLICE_TO);
//        stmts = stmts.stream().filter(stmt -> stmt.endsWith("CVE-2018-10899")).collect(Collectors.toList());
        List<String> stmts = getStmts();
        if (stmts.size() <= INDEX) return;
        String stmt = stmts.get(INDEX);

        processStmt(stmt);

        try {
            org.apache.commons.io.FileUtils.deleteDirectory(new File(OUTPUT));
        } catch (IOException e) {
            System.out.println("Failed to delete output directory");
        }
    }

    public static CompileResults processClassDiff(FixDiff fixDiff, ClassDiff classDiff) {
        String vulTargetClass = Path.of(fixDiff.getOutputPath(), classDiff.getOldClassPath()).toString();
        String fixTargetClass = Path.of(fixDiff.getOutputPath(), classDiff.getNewClassPath()).toString();
//        if (!fixTargetClass.equals("repos\\jolokia\\agent\\core\\src\\main\\java\\org\\jolokia\\backend\\BackendManager.java")) return new CompileResults();

        List<String> vulMethodsToKeep = new ArrayList<>(classDiff.getChangedMethods());
        vulMethodsToKeep.addAll(classDiff.getRemovedMethods());

        List<String> fixMethodsToKeep = new ArrayList<>(classDiff.getChangedMethods());
        fixMethodsToKeep.addAll(classDiff.getAddedMethods());

        List<String> initChanges = classDiff.getInitChanges();
        List<String> clinitChanges = classDiff.getClinitChanges();

        System.out.println("Target Class: " + fixTargetClass);
        System.out.println("Methods to keep for vul: " + vulMethodsToKeep);
        System.out.println("Methods to keep for fix: " + fixMethodsToKeep);
        System.out.println("<init> to keep: " + initChanges);
        System.out.println("<clinit> to keep: " + clinitChanges);

        try {
            MavenDependencyResolver.cleanupJars();
            checkoutVulVersion(fixDiff.getOutputPath(), fixDiff.getFirstCommitId());
            Set<String> vulPackages = PackageFinder.findPackageRoots(fixDiff.getOutputPath());
            boolean slicingVulResult = compile(vulPackages, Collections.emptySet(), vulTargetClass, vulMethodsToKeep, clinitChanges, initChanges, true,false, true);
            boolean stubbingVulResult = compile(vulPackages, Collections.emptySet(), vulTargetClass, vulMethodsToKeep, clinitChanges, initChanges, true,true, false);
            boolean ambiguousStubbingVulResult = compile(vulPackages, Collections.emptySet(), vulTargetClass, vulMethodsToKeep, clinitChanges, initChanges, true, false, false);

            boolean depVulResult = false;
            Set<String> vulPoms = PomFinder.findPomFilePaths(fixDiff.getOutputPath());
            MavenDependencyResolver.resolveDependencies(vulPoms, true);
            Set<String> vulJars = JarFinder.find(Jess.JAR_DIRECTORY);
            depVulResult = compile(vulPackages, vulJars, vulTargetClass, vulMethodsToKeep, clinitChanges, initChanges, true,false, false);

            MavenDependencyResolver.cleanupJars();
            checkoutFixVersion(fixDiff.getOutputPath(), fixDiff.getLastCommitId());
            Set<String> fixPackages = PackageFinder.findPackageRoots(fixDiff.getOutputPath());
            boolean slicingFixResult = compile(fixPackages, Collections.emptySet(), fixTargetClass, fixMethodsToKeep, clinitChanges, initChanges, true,false, true);
            boolean stubbingFixResult = compile(fixPackages, Collections.emptySet(), fixTargetClass, fixMethodsToKeep, clinitChanges, initChanges, true,true, false);
            boolean ambiguousStubbingFixResult = compile(fixPackages, Collections.emptySet(), fixTargetClass, fixMethodsToKeep, clinitChanges, initChanges, true,false, false);

            boolean depFixResult = false;
            Set<String> fixPoms = PomFinder.findPomFilePaths(fixDiff.getOutputPath());
            MavenDependencyResolver.resolveDependencies(fixPoms, true);
            Set<String> fixJars = JarFinder.find(Jess.JAR_DIRECTORY);
            depFixResult = compile(fixPackages, fixJars, fixTargetClass, fixMethodsToKeep, clinitChanges, initChanges, true,false, false);


            return new CompileResults(slicingVulResult, stubbingVulResult, ambiguousStubbingVulResult, depVulResult, slicingFixResult, stubbingFixResult, ambiguousStubbingFixResult, depFixResult);
//            return new CompileResults(slicingVulResult, false, false, false, slicingFixResult, false, false, false);
        }  catch (MissingObjectException e) {
            e.printStackTrace();
            return new CompileResults(true, false);
        } catch (Throwable e) {
            e.printStackTrace();
            return new CompileResults(false, true);
        }
    }

    public static void processFixDiff(String cveId, FixDiff fixDiff) {
        printCommits(fixDiff.getRepo(), fixDiff.getCommitIds());
        String fixId = fixDiff.getId();
        CombinedResults comb = new CombinedResults();

        for (ClassDiff classDiff : fixDiff.getChangedClasses()) {
            if (classDiff.getDiffType() != DiffType.CHANGED) continue;
            if (!hasChangesToCompile(classDiff)) continue;

            CompileResults cr = processClassDiff(fixDiff, classDiff);
            if (cr.missingCommit) {
                comb.setAllCompilable(false);
            } else {
                comb.increaseAllTotalFiles();
                comb.increaseCompileSuccess(cr);
            }
        }

        BuildResult slicingResult = new BuildResult(cveId, fixId, "slicing", comb.slicingVulResult, comb.slicingFixResult);
        BuildResult stubbingResult = new BuildResult(cveId, fixId, "stubbing", comb.stubbingVulResult, comb.stubbingFixResult);
        BuildResult aStubbingResult = new BuildResult(cveId, fixId, "ambiguous stubbing", comb.aStubbingVulResult, comb.aStubbingVulResult);
        BuildResult depsResult = new BuildResult(cveId, fixId, "deps", comb.depsVulResult, comb.depsFixResult);

        buildResults.add(slicingResult);
        buildResults.add(stubbingResult);
        buildResults.add(aStubbingResult);
        buildResults.add(depsResult);

        System.out.println(slicingResult);
        System.out.println(stubbingResult);
        System.out.println(aStubbingResult);
        System.out.println(depsResult);
        System.out.println("-------------------------------------------");

        Gson gson = new Gson();
        logger.log(gson.toJson(slicingResult));
        logger.log(gson.toJson(stubbingResult));
        logger.log(gson.toJson(aStubbingResult));
        logger.log(gson.toJson(depsResult));
    }

    public static void processCveDiff(CveDiff diff) {
        System.out.println("Current Statement: " + diff.getId());
        if (!hasChangesToCompile(diff)) return;

        for (FixDiff fixDiff : diff.getFixDiffs()) {
            if (!hasChangesToCompile(fixDiff)) continue;

            System.out.println("Current Fix: " + fixDiff.getId());
            processFixDiff(diff.getId(), fixDiff);

        }

    }

    public static void processStmt(String stmt) {
        Map<String, CveDiff> cveDiffs = differ.diffStatement(stmt);
        Map<String, CveDiff> sortedDiffs = sort(cveDiffs);

        for (Map.Entry<String, CveDiff> entry : sortedDiffs.entrySet()) {
            processCveDiff(entry.getValue());
        }
    }

    public static void processStmts(List<String> stmts) {
        for (String stmt : stmts) {
            processStmt(stmt);
        }
    }

    public static boolean compile(Set<String> packages, Set<String> deps, String targetClass, List<String> methods, List<String> clinit,
                                  List<String> init, boolean keepAsteriskImports, boolean failOnAmbiguity, boolean stubbingDisabled)  throws IOException {
        try {
            JessConfiguration jessConfiguration = new JessConfiguration(false, false, false, keepAsteriskImports, failOnAmbiguity, stubbingDisabled);
            Jess jess = new Jess(jessConfiguration, packages, deps);
            jess.preSlice(targetClass, methods, clinit, init);
            int result = jess.parse(targetClass);
            return result == 0;
        } catch (AmbiguityException e) {
            System.out.println("\u001B[31m" + "ambiguity" + "\u001B[0m");
            return false;
        } catch (Throwable e) {
            return false;
        }
    }

    public static void checkoutVulVersion(String repoPath, String commitId) throws IOException {
            try (Git git = Git.open(new File(repoPath))) {
                ObjectId previousCommitId = git.getRepository().resolve( commitId + "^" );
                git.checkout().setName(previousCommitId.getName()).call();
            } catch (GitAPIException e) {
                e.printStackTrace();
            }

    }

    public static void checkoutFixVersion(String repoPath, String commitId) throws IOException {
        try (Git git = Git.open(new File(repoPath))) {
            git.checkout().setName(commitId).call();
        } catch (GitAPIException e) {
            e.printStackTrace();
        }
    }


    public static void printCommits(String repo, List<String> commitIds) {
        System.out.println("Fix Commits: ");
        for (String commitId : commitIds) {
            String commitUrl = (repo + "/commit/" + commitId).replace("//commit", "/commit");
            System.out.println(commitUrl);
        }
    }

    public static List<String> getStmts() {
        File[] statementDirs = new File(KB_PATH).listFiles(File::isDirectory);
        Arrays.sort(statementDirs);
        return Arrays.stream(statementDirs)
                .map(sd -> Paths.get(sd.getAbsolutePath()).toFile())
                .filter(File::exists)
                .map(File::getAbsolutePath)
                .collect(Collectors.toList());
    }
    
    public static Map<String, CveDiff> sort(Map<String, CveDiff> diffs) {
        return diffs.entrySet().stream()
                    .sorted(Map.Entry.comparingByValue(Comparator.comparing(CveDiff::getId)))
                    .collect(Collectors.toMap(
                            Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new)
                    );
    }

    public static boolean hasChangesToCompile(CveDiff diff) {
        return diff.getFixDiffs().stream().anyMatch(Main::hasChangesToCompile);
    }

    public static boolean hasChangesToCompile(FixDiff diff) {
        return diff.getChangedClasses().stream().anyMatch(Main::hasChangesToCompile);
    }

    public static boolean hasChangesToCompile(ClassDiff diff) {
        List<String> vulMethodsToKeep = new ArrayList<>(diff.getChangedMethods());
        vulMethodsToKeep.addAll(diff.getRemovedMethods());

        List<String> fixMethodsToKeep = new ArrayList<>(diff.getChangedMethods());
        fixMethodsToKeep.addAll(diff.getAddedMethods());

        List<String> initChanges = diff.getInitChanges();
        List<String> clinitChanges = diff.getClinitChanges();

        return !vulMethodsToKeep.isEmpty() ||
                !fixMethodsToKeep.isEmpty() ||
                !initChanges.isEmpty() ||
                !clinitChanges.isEmpty();
    }
}
