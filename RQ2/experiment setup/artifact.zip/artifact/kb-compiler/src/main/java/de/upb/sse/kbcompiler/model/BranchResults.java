package de.upb.sse.kbcompiler.model;

public class BranchResults {
    public BranchResult slicingBranchResult;
    public BranchResult stubbingBranchResult;
    public BranchResult ambiguousStubbingBranchResult;

    public BranchResults(BranchResult slicingBranchResult, BranchResult stubbingBranchResult, BranchResult ambiguousStubbingBranchResult) {
        this.slicingBranchResult = slicingBranchResult;
        this.stubbingBranchResult = stubbingBranchResult;
        this.ambiguousStubbingBranchResult = ambiguousStubbingBranchResult;
    }

    public boolean isCompilable() {
        return slicingBranchResult.compilable || stubbingBranchResult.compilable || ambiguousStubbingBranchResult.compilable;
    }
}
