package de.upb.sse.kbcompiler.model;

public class Stats {
    public int compilable = 0;
    public int successfulFixCompilations = 0;
    public int successfulVulCompilations = 0;
    public int successfulVulAndFixCompilations = 0;

    public int compilableBranches = 0;
    public int fullBranchSuccess = 0;
    public int partialBranchSuccess = 0;

    public int compilableStatements = 0;
    public int fullSuccess = 0;
    public int partialSuccess = 0;

    public int missingCommits = 0;
}
