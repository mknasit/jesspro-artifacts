package de.upb.sse.kbcompiler.model;

public class BranchResult {
    public final boolean compilable;
    public final boolean vulSuccess;
    public final boolean fixSuccess;
    public final boolean partialSuccess;

    public BranchResult(boolean compilable, boolean vulSuccess, boolean fixSuccess, boolean partialSuccess) {
        this.compilable = compilable;
        this.vulSuccess = vulSuccess;
        this.fixSuccess = fixSuccess;
        this.partialSuccess = partialSuccess;
    }
}
