package de.upb.sse.kbcompiler.model;

public class AllStats {
    public Stats slicingStats = new Stats();
    public Stats stubbingStats = new Stats();
    public Stats ambiguousStubbingStats = new Stats();

    public void increaseCompilable(int amount) {
        this.slicingStats.compilable += amount;
        this.stubbingStats.compilable += amount;
        this.ambiguousStubbingStats.compilable += amount;
    }

    public void increaseCompilableBranches(int amount) {
        this.slicingStats.compilableBranches += amount;
        this.stubbingStats.compilableBranches += amount;
        this.ambiguousStubbingStats.compilableBranches += amount;
    }

    public void increaseCompilableStatements() {
        this.slicingStats.compilableStatements++;
        this.stubbingStats.compilableStatements++;
        this.ambiguousStubbingStats.compilableStatements++;
    }

    public void increaseMissingCommits() {
        this.slicingStats.missingCommits++;
        this.stubbingStats.missingCommits++;
        this.ambiguousStubbingStats.missingCommits++;
    }

}
