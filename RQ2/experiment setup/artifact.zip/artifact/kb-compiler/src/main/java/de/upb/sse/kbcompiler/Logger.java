package de.upb.sse.kbcompiler;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;

public class Logger {
    File logFile;

    public Logger(File logFile) {
        this.logFile = logFile;
        prepareFile();
    }

    public void log(String content) {
        try {
            Files.write(logFile.toPath(), (content + "\n").getBytes(), StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.out.println("Could not write to log file: " + logFile.getName());
            e.printStackTrace();
        }
    }

    private void prepareFile() {
        File dir = logFile.getParentFile();
        try {
            dir.mkdirs();
            if (!logFile.exists()) {
                Files.createFile(logFile.toPath());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
