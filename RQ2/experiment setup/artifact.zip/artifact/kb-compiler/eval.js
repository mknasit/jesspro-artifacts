const fs = require('fs');
const spawnSync = require('child_process').spawnSync;

const stopIndex = process.argv[2];
for (let i = 0; i < stopIndex; i++) {
    const code = spawnSync('java', ['-jar', 'target/kb-compiler-jar-with-dependencies.jar', '/project-kb/statements', i], { stdio: 'inherit', timeout: 7200000 });
    fs.rmSync('/root/.m2', { recursive: true, force: true });
    spawnSync('mvn', ['install', '-DskipTests'], { stdio: 'inherit', cwd: '/dependency-donwload-maven-plugin' });
}
