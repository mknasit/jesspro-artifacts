import fs from 'fs';

const aggregate = () => {
    const resultsJson = fs.readFileSync('input/single-builds.json').toString().trim();
    const splitResultsJson = resultsJson.split('\n');
    const results = splitResultsJson.map(comp => JSON.parse(comp.trim()));
    // const results = JSON.parse(resultsJson);

    const aggregatedResults = results.map(res => ({
        projectName: res.projectName,
        totalFiles: res.slicingResults.totalFiles,
        totalMethods: res.slicingResults.fileBuildResults.reduce((acc, fileRes) => acc += fileRes.totalMethods, 0),
        slicingSuccess: res.slicingResults.fileBuildResults.reduce((acc, fileRes) => acc += fileRes.compiledMethods, 0),
        slicingEquality: aggregateEqualityResults(res.slicingResults.fileBuildResults),
        stubbingSuccess: res.stubbingResults.fileBuildResults.reduce((acc, fileRes) => acc += fileRes.compiledMethods, 0),
        stubbingEquality: aggregateEqualityResults(res.stubbingResults.fileBuildResults),
        depsSuccess: res.depsResults.fileBuildResults.reduce((acc, fileRes) => acc += fileRes.compiledMethods, 0),
        depsEquality: aggregateEqualityResults(res.depsResults.fileBuildResults),
    }));

    // aggregatedResults.forEach(res => printAggregatedResult(res));
    console.log(aggregatedResults);
};

const aggregateEqualityResults = (fileBuildResults) => {
    const totalComparedMethods = fileBuildResults.reduce((acc, fbr) => acc += fbr.methodComparisons.length, 0);
    const equalMethods = fileBuildResults.reduce((acc, fbr) => acc += fbr.methodComparisons.filter(mc => mc.equal).length, 0);
    const wildcardEqualMethods = fileBuildResults.reduce((acc, fbr) => acc += fbr.methodComparisons.filter(mc => mc.wildcardEqual).length, 0);
    const levenshteinTotal = fileBuildResults.reduce((acc, fbr) => acc += fbr.methodComparisons.reduce((acc2, mc) => acc2 += mc.levenshteinDistance, 0), 0);
    const levenshteinAverage = levenshteinTotal / (totalComparedMethods - equalMethods);
    const normalizedLevenshteinTotal = fileBuildResults.reduce((acc, fbr) => acc += fbr.methodComparisons.reduce((acc2, mc) => acc2 += mc.normalizedLevenshteinDistance, 0), 0);
    const normalizedLevenshteinAverage = normalizedLevenshteinTotal / (totalComparedMethods - equalMethods);

    const equality = {
        totalComparedMethods,
        equalMethods,
        wildcardEqualMethods,
        levenshteinTotal,
        levenshteinAverage,
        normalizedLevenshteinAverage
    };

    return equality;
};

const printAggregatedResult = (result) => {
    console.log('Project:', result.projectName);
    console.log('Total files:', result.totalFiles);
    console.log('Total methods:', result.totalMethods);
    console.log(`Slicing comp success: ${result.slicingSuccess}/${result.totalMethods} (${(result.slicingSuccess / result.totalMethods * 100).toFixed(2)}%)`);
    console.log(`Stubbing comp success: ${result.stubbingSuccess}/${result.totalMethods} (${(result.stubbingSuccess / result.totalMethods * 100).toFixed(2)}%)`);
    console.log(`Deps comp success: ${result.depsSuccess}/${result.totalMethods} (${(result.depsSuccess / result.totalMethods * 100).toFixed(2)}%)`);
};

aggregate();