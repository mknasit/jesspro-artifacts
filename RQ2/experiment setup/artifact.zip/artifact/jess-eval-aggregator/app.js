import fs from 'fs';

const aggregateRandom = () => {
    // const resultsJson = fs.readFileSync('../jess-eval/logs/builds.json').toString().trim();
    const resultsJson = fs.readFileSync(process.argv[2]).toString().trim();
    const splitResultsJson = resultsJson.split('\n');
    const results = splitResultsJson.map(comp => JSON.parse(comp.trim()));
    // const results = JSON.parse(resultsJson);

    const aggregatedResults = results.map(res => ({
        projectName: res.projectName,
        mavenCompilationSuccess: res.depsResults && res.depsResults.length > 0 && res.depsResults[0].methodComparisons && res.depsResults[0].methodComparisons.length > 0,

        totalFiles: new Set(res.slicingResults.map(res => res.className)).size,
        totalMethods: res.slicingResults.length,
        directSuccess: res.directResults.reduce((acc, res) => acc += res.buildSuccess ? 1 : 0, 0),
        directTime: res.directResults.reduce((acc, res) => acc += res.buildSuccess ? res.compilationTimeMs : 0, 0),

        slicingSuccess: res.slicingResults.reduce((acc, methodRes) => acc += methodRes.buildSuccess ? 1 : 0, 0),
        slicingTime: res.slicingResults.reduce((acc, res) => acc += res.buildSuccess ? res.compilationTimeMs : 0, 0),
        slicingEquality: aggregateRandomEqualityResults(res.slicingResults),

        stubbingSuccess: res.stubbingResults.reduce((acc, methodRes) => acc += methodRes.buildSuccess ? 1 : 0, 0),
        stubbingTime: res.stubbingResults.reduce((acc, res) => acc += res.buildSuccess ? res.compilationTimeMs : 0, 0),
        stubbingEquality: aggregateRandomEqualityResults(res.stubbingResults),
        stubbingStats: aggregateStubbingStats(res.stubbingResults, res.slicingResults),

        depsSuccess: res.depsResults.reduce((acc, methodRes) => acc += methodRes.buildSuccess ? 1 : 0, 0),
        // depsSuccessWhenMavenSuccess: res.depsResults.reduce((acc, methodRes) => acc += methodRes.buildSuccess ? 1 : 0, 0),
        depsTime: res.depsResults.reduce((acc, res) => acc += res.buildSuccess ? res.compilationTimeMs : 0, 0),
        depsEquality: aggregateRandomEqualityResults(res.depsResults),
    }));

    // console.log(aggregatedResults);
    aggregateAllResults(aggregatedResults);
};

const aggregateRandomEqualityResults = (results) => {
    const totalComparedMethods = results.reduce((acc, mr) => acc += mr.methodComparisons.length, 0);
    const equalMethods = results.reduce((acc, mr) => acc += mr.methodComparisons.filter(mc => mc.equal).length, 0);
    const wildcardEqualMethods = results.reduce((acc, mr) => acc += mr.methodComparisons.filter(mc => mc.wildcardEqual).length, 0);
    const levenshteinTotal = results.reduce((acc, mr) => acc += mr.methodComparisons.reduce((acc2, mc) => acc2 += mc.levenshteinDistance, 0), 0);
    const levenshteinAverage = levenshteinTotal / (totalComparedMethods - equalMethods);
    const normalizedLevenshteinTotal = results.reduce((acc, mr) => acc += mr.methodComparisons.reduce((acc2, mc) => acc2 += mc.normalizedLevenshteinDistance, 0), 0);
    const normalizedLevenshteinAverage = normalizedLevenshteinTotal / (totalComparedMethods - equalMethods);

    const equality = {
        totalComparedMethods,
        equalMethods,
        wildcardEqualMethods,
        levenshteinTotal,
        levenshteinAverage,
        normalizedLevenshteinTotal,
        normalizedLevenshteinAverage
    };

    return equality;
};

const aggregateAllResults = (aggregatedResults) => {
    const projectAmount = aggregatedResults.length;
    const totalFiles = aggregatedResults.reduce((acc, res) => acc += res.totalFiles, 0);
    const totalMethods = aggregatedResults.reduce((acc, res) => acc += res.totalMethods, 0);

    const mavenProjectsCompilationSuccess = aggregatedResults.reduce((acc ,res) => acc += res.mavenCompilationSuccess ? 1 : 0, 0);
    const totalMethodsMavenCompilationSuccess = aggregatedResults.reduce((acc ,res) => acc += res.mavenCompilationSuccess ? res.totalMethods : 0, 0);

    const directSuccess = aggregatedResults.reduce((acc ,res) => acc += res.directSuccess, 0);
    const avgDirectTimeMs = aggregatedResults.reduce((acc, res) => acc += res.directTime, 0) / directSuccess;

    const slicingSuccess = aggregatedResults.reduce((acc, res) => acc += res.slicingSuccess, 0);
    const avgSlicingTimeMs = aggregatedResults.reduce((acc, res) => acc += res.slicingTime, 0) / slicingSuccess;
    const slicingEquality = aggregateAllEqulityResults(aggregatedResults.map(res => res.slicingEquality));

    const stubbingSuccess = aggregatedResults.reduce((acc, res) => acc += res.stubbingSuccess, 0);
    const avgStubbingTimeMs = aggregatedResults.reduce((acc, res) => acc += res.stubbingTime, 0) / stubbingSuccess;
    const stubbingEquality = aggregateAllEqulityResults(aggregatedResults.map(res => res.stubbingEquality));
    const avgStubbingStats = aggregateAllStubbingStats(aggregatedResults.map(res => res.stubbingStats), stubbingSuccess, slicingSuccess);

    const depsSuccess = aggregatedResults.reduce((acc, res) => acc += res.depsSuccess, 0);
    const depsMavenSuccess = aggregatedResults.reduce((acc, res) => acc += res.mavenCompilationSuccess ? res.depsSuccess : 0, 0);
    const avgDepsTimeMs = aggregatedResults.reduce((acc, res) => acc += res.depsTime, 0) / depsSuccess;
    const depsEquality = aggregateAllEqulityResults(aggregatedResults.map(res => res.depsEquality));

    const results = { projectAmount, totalFiles, totalMethods, mavenProjectsCompilationSuccess, totalMethodsMavenCompilationSuccess, directSuccess, avgDirectTimeMs, 
        slicingSuccess, avgSlicingTimeMs, slicingEquality, stubbingSuccess, avgStubbingTimeMs, stubbingEquality, 
        // avgStubbingStats, 
        depsSuccess, depsMavenSuccess, avgDepsTimeMs, depsEquality };
    
        fs.writeFileSync(process.argv[3], JSON.stringify(results, null, 2));
};

const aggregateAllEqulityResults = (aggregatedResults) => {
    const totalComparedMethods = aggregatedResults.reduce((acc, res) => acc += res.totalComparedMethods, 0);
    const equalMethods = aggregatedResults.reduce((acc, res) => acc += res.equalMethods, 0);
    const wildcardEqualMethods = aggregatedResults.reduce((acc, res) => acc += res.wildcardEqualMethods, 0);
    const levenshteinTotal = aggregatedResults.reduce((acc, res) => acc += res.levenshteinTotal, 0);
    const levenshteinAverage = levenshteinTotal / totalComparedMethods;
    const normalizedLevenshteinTotal = aggregatedResults.reduce((acc, res) => acc += res.normalizedLevenshteinTotal, 0);
    const normalizedLevenshteinAverage = normalizedLevenshteinTotal / totalComparedMethods;

    return { totalComparedMethods, equalMethods, wildcardEqualMethods, levenshteinTotal, levenshteinAverage, normalizedLevenshteinAverage };
};

const aggregateStubbingStats = (stubbingResults, slicingResults) => {
    const aggregatedStubbingStats = {
        stubbedFiles: 0,
        stubbedLines: 0,
        stubbedFields: 0,
        stubbedMethods: 0,
        stubbedConstructors: 0
    };

    const maxStubbingStats = {
        stubbedFiles: 0,
        stubbedLines: 0,
        stubbedFields: 0,
        stubbedMethods: 0,
        stubbedConstructors: 0
    };

    for (let i = 0; i < stubbingResults.length; i++) {
        const { stubbingStats, buildSuccess } = stubbingResults[i];
        const { slicingSuccess } = slicingResults[i];
        if (slicingSuccess) continue;
        if (!buildSuccess) continue;
        aggregatedStubbingStats.stubbedFiles += stubbingStats.stubbedFiles;
        aggregatedStubbingStats.stubbedLines += stubbingStats.stubbedLines;
        aggregatedStubbingStats.stubbedFields += stubbingStats.stubbedFields;
        aggregatedStubbingStats.stubbedMethods += stubbingStats.stubbedMethods;
        aggregatedStubbingStats.stubbedConstructors += stubbingStats.stubbedConstructors;

        if (maxStubbingStats.stubbedFiles < stubbingStats.stubbedFiles) maxStubbingStats.stubbedFiles = stubbingStats.stubbedFiles;
        if (maxStubbingStats.stubbedLines < stubbingStats.stubbedLines) maxStubbingStats.stubbedLines = stubbingStats.stubbedLines;
        if (maxStubbingStats.stubbedFields < stubbingStats.stubbedFields) maxStubbingStats.stubbedFields = stubbingStats.stubbedFields;
        if (maxStubbingStats.stubbedMethods < stubbingStats.stubbedMethods) maxStubbingStats.stubbedMethods = stubbingStats.stubbedMethods;
        if (maxStubbingStats.stubbedConstructors < stubbingStats.stubbedConstructors) maxStubbingStats.stubbedConstructors = stubbingStats.stubbedConstructors;
    }

    // for (const stubbingResult of stubbingResults) {
    //     const { stubbingStats, buildSuccess } = stubbingResult;
    //     if (!buildSuccess) continue;
    //     aggregatedStubbingStats.stubbedFiles += stubbingStats.stubbedFiles;
    //     aggregatedStubbingStats.stubbedLines += stubbingStats.stubbedLines;
    //     aggregatedStubbingStats.stubbedFields += stubbingStats.stubbedFields;
    //     aggregatedStubbingStats.stubbedMethods += stubbingStats.stubbedMethods;
    //     aggregatedStubbingStats.stubbedConstructors += stubbingStats.stubbedConstructors;
    // }

    return { aggregatedStubbingStats, maxStubbingStats };
};

const aggregateAllStubbingStats = (stubbingStats, stubbingSuccess, slicingSuccess) => {
    const aggregatedStubbingStats = {
        stubbedFiles: 0,
        stubbedLines: 0,
        stubbedFields: 0,
        stubbedMethods: 0,
        stubbedConstructors: 0
    };

    const aggregatedMaxStubbingStats = {
        stubbedFiles: 0,
        stubbedLines: 0,
        stubbedFields: 0,
        stubbedMethods: 0,
        stubbedConstructors: 0
    };

    for (const stubbingStat of stubbingStats) {
        const stat = stubbingStat.aggregatedStubbingStats;
        aggregatedStubbingStats.stubbedFiles += stat.stubbedFiles;
        aggregatedStubbingStats.stubbedLines += stat.stubbedLines;
        aggregatedStubbingStats.stubbedFields += stat.stubbedFields;
        aggregatedStubbingStats.stubbedMethods += stat.stubbedMethods;
        aggregatedStubbingStats.stubbedConstructors += stat.stubbedConstructors;
    }

    for (const stubbingStat of stubbingStats) {
        const stat = stubbingStat.maxStubbingStats;
        if (aggregatedMaxStubbingStats.stubbedFiles < stat.stubbedFiles) aggregatedMaxStubbingStats.stubbedFiles = stat.stubbedFiles;
        if (aggregatedMaxStubbingStats.stubbedLines < stat.stubbedLines) aggregatedMaxStubbingStats.stubbedLines = stat.stubbedLines;
        if (aggregatedMaxStubbingStats.stubbedFields < stat.stubbedFields) aggregatedMaxStubbingStats.stubbedFields = stat.stubbedFields;
        if (aggregatedMaxStubbingStats.stubbedMethods < stat.stubbedMethods) aggregatedMaxStubbingStats.stubbedMethods = stat.stubbedMethods;
        if (aggregatedMaxStubbingStats.stubbedConstructors < stat.stubbedConstructors) aggregatedMaxStubbingStats.stubbedConstructors = stat.stubbedConstructors;
    }

    return {
        avgStubbingStats: {
            stubbedFiles: aggregatedStubbingStats.stubbedFiles / (stubbingSuccess - slicingSuccess),
            stubbedLines: aggregatedStubbingStats.stubbedLines / (stubbingSuccess - slicingSuccess),
            stubbedFields: aggregatedStubbingStats.stubbedFields / (stubbingSuccess - slicingSuccess),
            stubbedMethods: aggregatedStubbingStats.stubbedMethods / (stubbingSuccess - slicingSuccess),
            stubbedConstructors: aggregatedStubbingStats.stubbedConstructors / (stubbingSuccess - slicingSuccess)
        },
        maxStubbingStats: aggregatedMaxStubbingStats
    }
};


const getTimeInS = (res) => {
    return res.reduce((acc, methodRes) => acc += methodRes.compilationTimeMs, 0) / 
        res.reduce((acc, methodRes) => acc += methodRes.buildSuccess ? 1 : 0, 0) 
        / 1000;
};

const getDiffs = () => {
    const resultsJson = fs.readFileSync('input/single-builds-7.json').toString().trim();
    const splitResultsJson = resultsJson.split('\n');
    const results = splitResultsJson.map(comp => JSON.parse(comp.trim()));

    const diffs = [];
    const projects = [];

    results.forEach(res => {
        res.slicingResults.forEach(slicingRes => {
            const methodComp = slicingRes.methodComparisons;
            if (methodComp.length === 0) return;
            const mc = methodComp[0];
            if (mc.equal) return;

            const diff = {
                project: res.projectName,
                className: slicingRes.className,
                methodSignature: slicingRes.methodSignature,
                nld: (mc.normalizedLevenshteinDistance * 100).toFixed(1)
            };

            if (!projects.includes(res.projectName)) projects.push(res.projectName);

            
            console.log('------------------------------');
            console.log(res.projectName);
            console.log(slicingRes.className);
            console.log(`${slicingRes.methodSignature}: ${(mc.normalizedLevenshteinDistance * 100).toFixed(1)}%`);
            
            diffs.push(diff);
        });
    });

    fs.writeFileSync('output/diffs.json', JSON.stringify(diffs));
};

const stubbingStatsMedian = () => {
    const resultsJson = fs.readFileSync('input/single-builds-9.json').toString().trim();
    const splitResultsJson = resultsJson.split('\n');
    const results = splitResultsJson.map(comp => JSON.parse(comp.trim()));


    const slicingResults = results.flatMap(res => res.slicingResults);
    const stubbingResults = results.flatMap(res => res.stubbingResults);
    const relevantResults = stubbingResults.filter((res, idx) => {
        if (!res.buildSuccess) return false;
        if (slicingResults[idx].buildSuccess) return false;
        return true;
    });
    const stubbingStats = relevantResults.map(res => res.stubbingStats);
       
    console.log('files: ' + getMedian(stubbingStats, 'stubbedFiles'));
    console.log('lines: ' + getMedian(stubbingStats, 'stubbedLines'));
    console.log('fields: ' + getMedian(stubbingStats, 'stubbedFields'));
    console.log('methods: ' + getMedian(stubbingStats, 'stubbedMethods'));
    console.log('constructors: ' + getMedian(stubbingStats, 'stubbedConstructors'));
};

const getMedian = (objectList, key) => {
    const relevantObjs = objectList.map(obj => obj[key]);
    relevantObjs.sort((a, b) => a - b);

    const length = relevantObjs.length;

  // Check if the number of values is even or odd
  if (length % 2 === 0) {
    // If even, calculate the average of the middle two values
    const midIndex1 = length / 2 - 1;
    const midIndex2 = length / 2;
    return (relevantObjs[midIndex1] + relevantObjs[midIndex2]) / 2;
  } else {
    // If odd, return the middle value
    const midIndex = Math.floor(length / 2);
    return relevantObjs[midIndex];
  }
};

aggregateRandom();
// getDiffs();
// stubbingStatsMedian();